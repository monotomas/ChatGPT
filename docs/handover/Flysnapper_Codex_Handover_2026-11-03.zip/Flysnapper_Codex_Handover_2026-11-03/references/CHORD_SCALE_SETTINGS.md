# Flysnapper – skalaoppsett på baksiden

Fastlagt brukerkrav, 3. november 2026. Tilhører handoverens spesifikasjon 2.

## 1. Formål

Brukeren bestemmer hvilken skala som skal tillates over hver akkordtype. Flysnapper leveres med anbefalte standardvalg, men alle er redigerbare. Dette skal være en enkel tabell, ikke en automatisk motor for tonearts-/funksjonsanalyse. Standardvalg trenger ikke dekke alle harmoniske eventualiteter fordi brukeren kan velge selv.

## 2. Grensesnitt

- En flip-knapp åpner en bakside i samme pluginvindu; en tydelig returknapp viser forsiden igjen.
- Hver akkordtype har én rad og én nedtrekksmeny for skalatype.
- Alle Flysnappers 19 skalaer skal være tilgjengelige på hver rad, også Chromatic. Ingen alternativ skal fjernes eller deaktiveres på grunn av antatt musikalsk uforenlighet.
- Det skal være plass til hele biblioteket. Bruk leselig rullbar tabell ved behov; ikke krymp teksten for å presse alt inn samtidig.
- Behold Buffkillers stil, kontroller, typografi og farger.
- Anbefalingen er førstegangsvalget. Vis gjerne fabrikkvalget separat eller i tooltip når brukeren har valgt noe annet. Gjenoppretting av standarder må være uttrykkelig og må ikke skje ved flip eller gjenåpning.
- Forsiden beholder stor akkordvisning. Vis aktiv skala under akkorden og det effektive settet i Allowed Notes.
- Flip skal ikke endre modus, avbryte prosessering eller slippe aktive noter.

Dette er en innstillingsside i MIDI-to-MIDI-modulen, ikke en tredje prosesseringsmodul.

## 3. Oppførsel

Én oppføring gjelder en akkordtype i alle grunntoner. Et valg av Dorian for m7 brukes som B-dorisk ved Bm7, E-dorisk ved Em7 osv. Den valgte skalaen transponeres til gjenkjent grunntone og brukes i alle oktaver. Inversjon skal ikke bli en utilsiktet transponering til basstonen.

Hver utvidet type har egen oppføring. Et valg for m7 endrer ikke m9, m11, m13 eller m13b5. Gjenkjenningsvarianter med utelatelser eller tillegg som hører til samme underliggende bibliotektype bruker type-ID-en, ikke den ferdig formatterte visningsteksten som nøkkel.

Brukerens valg bestemmer skalaen også når det avviker fra anbefalingen. Ikke legg til skjult kompatibilitetsfiltrering, automatisk skalaomvalg, familiearv eller sammenslåing av alternative skalaer. Tidligere forslag om en egen «Behold akkordtoner»-bryter er ikke et vedtatt krav; denne revisjonens Chord Scale beskriver valgt skalas tonesett uten en skjult union med akkordnotene. Chord Notes forblir tilgjengelig for direkte korreksjon til mottatte akkordtoner.

Skalalistens autoritative innhold står i hoveddokumentets punkt 5: de 18 Buffkiller-skalaene pluss Chromatic. Nye skalaer er ikke nødvendig for denne funksjonen. Menyene bør bruke samme datakilde som Fixed Scale, slik at senere bevisste utvidelser blir tilgjengelige begge steder.

## 4. Standardvalg og lagring

Hver type skal ha et dokumentert anbefalt fabrikkvalg fra skalalisten. Det foreligger ikke en endelig tabell med 50 godkjente anbefalinger i denne handoveren. Codex skal velge og dokumentere rimelige startverdier under implementasjonen. Dette krever ikke ny godkjenning av hver anbefaling; valgbarheten er brukerens uttrykkelige løsning på harmoniske preferanser.

Lagre hele tabellen i hver plugininstans' prosjekt-/preset-tilstand. Bruk stabile akkordtype-ID-er og skala-ID-er; ikke kun radnummer, språktekst eller typeindeks i et generert bibliotek. Ved senere utvidelser skal eksisterende brukervalg bevares, mens nye typer får fabrikkvalg. Endring i én instans skal ikke påvirke andre instanser.

Et eventuelt separat filformat for eksport/import av brukeroppsett er ikke et krav nå. Tilstandslagring i verten er nødvendig.

## 5. Sanntid og akkordtolkning

Korreksjonen trenger numerisk type-ID og grunntone før den kan bruke tabellen. Dette må være uavhengig av om GUI er åpent. Forbered oppslag før sanntidsprosessering, og bruk avgrenset numerisk arbeid i prosesseringen. Strengbygging, dynamisk kandidatallokering og GUI-oppdateringer skal ikke ligge i MIDI-hendelsenes kritiske vei.

Det skal ikke innføres lookahead eller venting på framtidige akkorder. Eksisterende krav om akkorden ved gjenkjennings-/Note On-tidspunktet gjelder fortsatt. Note Off følger sin opprinnelige binding også etter endring av skalaoppsett.

Uklar type/grunntone og flere gyldige akkordkandidater trenger en deterministisk dokumentert policy; tabellen løser ikke selve gjenkjenningstvetydigheten. Dette er en avgrenset videre detalj, ikke et pålegg om å kartlegge all harmonilære. Holdte noter ved skalaendring og tomt akkordsett er fortsatt de åpne overgangsspørsmålene fra hoveddokumentet.

## 6. Kontrollpunkter

1. Nøyaktig én rad per bibliotektype; ingen manglende eller dupliserte typer.
2. Samtlige 19 skalaer tilgjengelige på samtlige 50 rader, fra én felles skalaliste.
3. Et ikke-anbefalt valg blir faktisk brukt; Chromatic tillater alle pitch classes.
4. En regel transponeres riktig i alle 12 grunntoner og bevarer utøverens register.
5. Endring av én type endrer ikke andre typer eller andre plugininstanser.
6. Lagre/gjenåpne og preset round-trip bevarer alle valg, også når standardene senere endres.
7. Flip, lukket GUI og åpnet bakside gir identisk MIDI-resultat og ingen nye hengende noter.
8. Korreksjon venter ikke på GUI-timer, navn eller strengbehandling.
9. Eksisterende Note On/Off-binding overlever endring av tabellen; overgangsoppførsel følger valgt policy.

## 7. Full typeoversikt fra vedlagt Buffkiller-kilde

Kilde: `Buffkiller/Source/ChordDictionary.h`, `correctedChordPatterns`, 50 oppføringer. Nummeret nedenfor er kun en lesereferanse, ikke en anbefalt lagrings-ID. C-eksemplene viser suffiksene entydig; brukeroppsettet gjelder alle grunntoner.

| Nr. | Type/suffiks | Eksempel |
|---|---|---|
| 1 | Durtreklang (tomt suffiks) | C |
| 2 | `m` | Cm |
| 3 | `sus2` | Csus2 |
| 4 | `sus4` | Csus4 |
| 5 | `5` | C5 |
| 6 | `5/7` | C5/7 |
| 7 | `6` | C6 |
| 8 | `m6` | Cm6 |
| 9 | `6/9` | C6/9 |
| 10 | `7` | C7 |
| 11 | `Maj7` | CMaj7 |
| 12 | `m7` | Cm7 |
| 13 | `mMaj7` | CmMaj7 |
| 14 | `m7b5` | Cm7b5 |
| 15 | `dim7` | Cdim7 |
| 16 | `7sus4` | C7sus4 |
| 17 | `7sus4b9` | C7sus4b9 |
| 18 | `7b5` | C7b5 |
| 19 | `7#5` | C7#5 |
| 20 | `7b9` | C7b9 |
| 21 | `7#9` | C7#9 |
| 22 | `7#11` | C7#11 |
| 23 | `7b13` | C7b13 |
| 24 | `7b5b9` | C7b5b9 |
| 25 | `7b5#9` | C7b5#9 |
| 26 | `7#5b9` | C7#5b9 |
| 27 | `7#5#9` | C7#5#9 |
| 28 | `Maj7#5` | CMaj7#5 |
| 29 | `Maj7#9` | CMaj7#9 |
| 30 | `Maj7#11` | CMaj7#11 |
| 31 | `9` | C9 |
| 32 | `Maj9` | CMaj9 |
| 33 | `m9` | Cm9 |
| 34 | `mMaj9` | CmMaj9 |
| 35 | `9sus4` | C9sus4 |
| 36 | `9#11` | C9#11 |
| 37 | `11` | C11 |
| 38 | `Maj11` | CMaj11 |
| 39 | `m11` | Cm11 |
| 40 | `m11b5` | Cm11b5 |
| 41 | `13` | C13 |
| 42 | `Maj13` | CMaj13 |
| 43 | `mMaj13` | CmMaj13 |
| 44 | `13b9` | C13b9 |
| 45 | `13#9` | C13#9 |
| 46 | `13sus4` | C13sus4 |
| 47 | `13sus4b9` | C13sus4b9 |
| 48 | `m13` | Cm13 |
| 49 | `13add#9` | C13add#9 |
| 50 | `m13b5` | Cm13b5 |
