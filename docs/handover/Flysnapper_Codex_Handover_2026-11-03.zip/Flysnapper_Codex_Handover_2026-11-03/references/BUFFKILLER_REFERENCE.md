# Buffkiller som referanse for Flysnapper

Inspisert 3. november 2026. Vedlagt original: `Buffkiller_1.0.0_Komplett_Versaler.zip`.

Arkivet er en komplett kilde-/byggepakke, ikke en forhåndskompilert Windows-plugin. Det er bevart uendret i denne handoveren. Alle stier nedenfor er relative til `Buffkiller/` etter utpakking av dette indre arkivet.

## 1. Avgrensning

Buffkiller er et ferdig harmonisk DSP-filter med bass-attenuering før og etter harmonisk filtrering. Referansen kan brukes til engineering, skalaer, akkordgjenkjenning og visuell kontinuitet. Flysnapper skal ikke være en gradvis ombygging eller oppdatering av Buffkiller.

Kilden viser en kontinuerlig filterbank for audio; FFT brukes til visning. Dette er ikke en pitch-to-MIDI-motor. Ikke forveksle spektrumanalysen eller akkordnavngivningen fra MIDI med deteksjon av spilte toner i audio.

## 2. Les disse filene først

| Fil | Relevant læring/gjenbruk |
|---|---|
| `Source/PluginEditor.cpp` og `.h` | LookAndFeel, farger, vridere, knapper, fonter, tooltips, Allowed Notes og akkordvisning. |
| `Source/ChordNames.h` | Akkordkandidater, navngivning, enharmonisk stavemåte, utelatelser og ukjent-sett-fallback. Headerimplementasjon; det finnes ikke en tilhørende ChordNames.cpp. |
| `Source/ChordDictionary.h` | 50 korrigerte akkordmønstre i denne pakken. |
| `Source/ChordInput.h` | Kompakt akkordsnapshot med pitch classes, reell laveste MIDI-note og toneorden. |
| `Source/DspCore.cpp` | De 18 faktiske skaladefinisjonene og MIDI-tilstand som referanse. |
| `Source/PluginProcessor.cpp` og `.h` | Parameter/state-mønstre og sanntids-/GUI-skille. Ikke kopier audio-/MIDI-wrapperen ukritisk. |
| `CMakeLists.txt` | Prosjekt, JUCE-binding, MSVC UTF-8 og testmål. |
| `build_plugin.py`, `BUILD_BUFFKILLER.bat` | Verktøyoppdagelse, låst JUCE, Unicode-håndtering, bygg/test/installasjon. Tilpasses som nytt Flysnapper-oppsett. |
| `Tests/` | Motor-, realtime-, plugin-, faktisk VST3- og Python-byggetester. |
| `Data/Chords/` | Korrigert akkordgrunnlag og dokumenterte tillegg. |
| `docs/RELEASE_1.0.0.md` | Hva den ferdige pakken inneholder og hva de historiske testene faktisk dekket. |
| `docs/ARCHITECTURE.md` | Referansearkitektur; les sammen med aktuell kode. |

## 3. Visuell referanse fra aktuell kode

`BuffkillerLook` arver `juce::LookAndFeel_V4`. Opaque farger uten alfaprefikset:

| Rolle | Hex |
|---|---|
| Bakgrunn | `#141B22` |
| Panel | `#1D2731` |
| Kant | `#344351` |
| Hovedtekst | `#EDF2F5` |
| Sekundærtekst | `#9BADBB` |
| Oransje | `#FFB15D` |
| Blå | `#5DAEFF` |
| Grønn | `#58D7BB` |
| Vriderkropp | `#10171D` |
| Tooltip-bakgrunn | `#283644` |

Koden bruker `juce::Font` uten en eksplisitt navngitt fontfamilie. Vanlige kontroller bruker 13, tittelen bruker 31 fet, og nåværende akkordetikett bruker 14 fet. Ikke påstå at Buffkiller bruker en bestemt innbygd eller lisensiert spesialfont.

Vriderne har mørk kropp, kant, en farget bue med 3 pikslers strek og peker med 2,5 pikslers strek. De bruker RotaryHorizontalVerticalDrag, verdi under og dobbeltklikk for reset. Toggle-knapper har oransje markering. Panelene har avrundede hjørner; notechips er små avrundede felt. Tooltips følger Help-innstillingen og en TooltipWindow med 400 ms ventetid.

Allowed Notes er 12 tonefelt; referansen bruker 32 × 24 logiske piksler per felt med 38 pikslers avstand mellom startposisjoner. Flysnapper kan tilpasse størrelsen og layouten, men den aktive masken må være tydelig.

Buffkillers akkordfelt er bare 26 piksler høyt ved dagens plassering og har 14 fet tekst. Dette skal **ikke** kopieres som størrelse til Flysnapper. Den nye bestillingen krever en betydelig større, selvstendig akkordvisning for utøveren. Palette og kontrollstil er referanser; gammel informasjonshierarki og spektralgraf er ikke layoutkrav.

Buffkiller bruker engelske UI-etiketter, versaltittel og byline «by Olav Lægreid». Samme språklige/visuelle linje er et naturlig forslag for Flysnapper; eksakt UI-skisse skal vurderes senere.

## 4. Akkordgjenkjenning

`ChordInput` bevarer faktisk bass/voicing i tillegg til masken. `ChordNames.h` bygger en oppslagstabell med 4096 masker ved første GUI-forespørsel, utenfor audiotråden. Kandidatene bygger på de korrigerte mønstrene og eksplisitt tillatte utelatelser. Det er ikke en generell regel om å fylle inn alle manglende akkordtoner.

Referansen krever en meningsfull kandidat med tilstedeværende grunntone og tillatt bassrolle etter mønsteret; den finner ikke opp vilkårlige røtter. Færre utelatelser rangeres høyere. Flere gyldige navn kan beholdes. Hvis intet navn passer, vises faktiske noter. Detaljer ligger i tooltip; kortvisningen kan vise to alternativer og antall øvrige.

Flysnappers større visningsflate kan presentere alternativene tydeligere. Ikke endre gjenkjenningslogikken tilfeldig for å få ett stort navn. I Chord Notes er mottatt pitch-class-maske autoritativ. I Chord Scale brukes gjenkjent type/grunntone til å slå opp brukerens valgte skala; det er denne skalaens maske som styrer korreksjonen. Akkordtolkningen er dermed også funksjonell i Flysnapper, selv om Buffkiller brukte navnene som GUI-informasjon. Se `CHORD_SCALE_SETTINGS.md`.

Dette krever å skille numerisk gjenkjenning fra strengformatering. Den eksisterende lazily initialiserte GUI-tabellen må ikke flyttes direkte inn i audiotråden. Forbered en avgrenset numerisk representasjon før prosessering og behold streng-/tooltip-arbeid utenfor audiotråden.

Bevar blant annet disse konvensjonene:

- `Maj7`, ikke vilkårlig annen kapitalisering; liten `m` for moll.
- `C5` betyr C/G; `C5/7` betyr C/G/Bb.
- Bevar m11b5-familien og dokumenterte utelatelser, inkludert at 11 ofte utelates i relevante b5-utvidelser.
- Bevar tilleggene m13, 13add#9 og m13b5.
- Enharmonisk tekst må ikke endre numeriske pitch classes.

`Data/Chords/ADDITIONS_0.1.6.md` dokumenterer blant annet følgende regresjonseksempler, med toner ordnet fra lavest til høyest:

| Inndata | Forventet navn |
|---|---|
| B, E, G, D, F#, A, C# | Em13 |
| B, E, G, D, F#, A, C#, G# | E13add#9 |
| B, D, F#, A, C#, E, G#, D# | B13add#9 |
| F#, C, E, A, D#, G# | F#m13b5, med 11 (B) utelatt |

Kopier ikke bare disse eksemplene; behold hele det korrigerte datagrunnlaget og relevante tester. Skalatabellen i hoveddokumentet er hentet fra `scales()` i `DspCore.cpp`, med Chromatic lagt til som et Flysnapper-krav.

## 5. Bygging og testing

Referansens `build_plugin.py` bruker JUCE-tag `8.0.16-security` og commit `ea77444750de45e036e0279bb0291144bf8e3688`. Den har særskilt Unicode-rettelse/-probe for juceaide og Windows-stier. Bevar den dokumenterte løsningen ved gjenbruk, og ikke bytt den ut med tilfeldige ANSI-kall.

De fire CTest-gruppene i referansen er BuffkillerCore, BuffkillerRealtime, BuffkillerPluginSmoke og BuffkillerActualVst3. Flysnapper trenger egne tilsvarende relevante tester med sin egen MIDI-utgang og bussarkitektur. `Tests/Vst3HostTests.cpp` er særlig nyttig som mønster for å teste den faktiske kompilerte modulen.

Historiske logger og antall tester i referansepakken er ikke nye resultater fra handoverarbeidet. Buffkillers release-notat skiller selv mellom lokale kontroller og faktisk Windows-/Ableton-verifikasjon. Oppretthold dette skillet.

## 6. Hva som må endres eller holdes utenfor

Buffkillers CMake angir `IS_SYNTH FALSE`, `NEEDS_MIDI_INPUT TRUE`, `NEEDS_MIDI_OUTPUT FALSE`, `IS_MIDI_EFFECT FALSE` og kategoriene Fx/Filter/Dynamics. Prosessoren er laget for å bruke MIDI som filterkontroll og tømmer MIDI-utgangen. Dette er ikke riktig Flysnapper-konfigurasjon.

Flysnapper trenger nye produkt-/pluginidentiteter og et nytt tilstandsskjema, instrumentklassifisering for Live, sidechain-audio og faktisk MIDI-utgang. Ingen gamle Buffkiller-parameter-ID-er eller binæridentiteter skal brukes som en bakvei til migrering av det ferdige produktet.

Følgende funksjoner følger ikke automatisk med: harmonisk audiofilter, Bass Attenuator Pre/Post, tailbehandling, spektralgraf, grafens frequency/level limits og tilhørende filterparametere. Akkordgjenkjenning, skalaer, Allowed Notes og stil er derimot uttrykkelig relevante for Flysnapper.

Bevar `LICENSE.txt` og aktuelle SPDX-/opphavsnotiser ved faktisk kildegjenbruk. Referansepakken beholdes urørt; Flysnapper-arbeidet skjer i sitt eget prosjekt.
