# Flysnapper – handover til Codex

**Versjon:** spesifikasjon 2, 3. november 2026  
**Bestiller:** Olav Lægreid  
**Mål:** Windows 11, x64 VST3, Ableton Live 12 Suite  
**Status:** design og utviklingsgrunnlag; ingen Flysnapper-binær er bygget eller testet i denne leveransen.

**Revisjon 2:** Brukerdefinert skalatype per akkordtype, redigert på en bakside som åpnes med en flip-funksjon. Alle 50 typer i Buffkiller-referansen får hver sin meny med alle 19 Flysnapper-skalaer. Akkordtolkningen kan nå påvirke korreksjonen gjennom brukerens valgte skala. Dette erstatter tidligere begrensninger til mottatte akkordtoner i den nye Chord Scale-modusen. Øvrige produktkrav gjelder fortsatt. Les også `references/CHORD_SCALE_SETTINGS.md`.

## 1. Oppdrag og kravstatus

Flysnapper skal gjøre live audio om til MIDI og korrigere MIDI til tillatte toner fra et akkordspor eller en valgt skala. De to funksjonene skal kunne brukes hver for seg og sammen. Lav forsinkelse ved faktisk spilling er avgjørende.

Dette dokumentet samler de nyeste brukerbeslutningene og erstatter eldre motstridende antagelser. «Fastlagt» betyr brukerkrav. «Anbefalt» betyr et begrunnet forslag for implementering eller prototype, ikke en ny brukerbeslutning. «Åpent» betyr at en musikalsk regel eller teknisk egenskap ennå ikke er avgjort eller verifisert.

| Tema | Gjeldende beslutning |
|---|---|
| Produkt | Flysnapper er et eget prosjekt. Buffkiller Windows 1.0.0 er ferdig og funksjonelt fryst. |
| Format og vert | VST3, Windows x64, Ableton Live 12 Suite. Ikke gjenåpne diskusjonen om Max for Live eller andre formater. |
| Spor | Flysnapper skal ligge på et MIDI-spor. Utviklingsretningen er en instrumentklassifisert VST3 med sidechain og MIDI-utgang. Vertens faktiske oppførsel må testes. |
| Funksjonsmoduler | 1: Pitch-to-MIDI. 2: MIDI-to-MIDI. Ingen separat felles note- og hendelsesmotor som tredje funksjonsmodul. |
| Vanlig MIDI | MIDI-to-MIDI skal kunne motta både generert og eksternt MIDI, også samtidig. Ingen obligatorisk gjensidig utelukkende kildevelger. |
| Akkordtolkning | Chord Notes bruker mottatte pitch classes; Chord Scale bruker valgt skala for gjenkjent akkordtype og grunntone. Begge gjelder uavhengig av akkordsporets register. |
| Akkord–skala-oppsett | Bakside med én skalameny per akkordtype. Alle skalaer tilgjengelige på alle rader. Anbefalt standard er redigerbar; brukerens valg gjelder. |
| Nærmeste tone | Minste absolutte halvtonedistanse til en tillatt MIDI-note. Oktavgrense kan krysses; instrumentets register skal bevares. |
| Tidspunkt | Korriger mot akkorden som gjelder når MIDI-noten dannes/behandles, ikke en tidligere akkord ved det akustiske anslaget. |
| Tie-break | Tidligere løpsretning, særregel ved to like foregående toner, ellers opp. Ingen lookahead. |
| Grensesnitt | Buffkiller-stil, akkordgjenkjenning og Allowed Notes er krav. Akkordnavnet får vesentlig større fysisk plass. |
| Tonehøyde | A4 = 440 Hz. Bruk MIDI-notenumre i tester der vertsprogrammets oktavnavn kan skape tvetydighet. |
| Leveranser | Komplette erstatningspakker, testing før installasjon, enkel bruk. Brukeren skal ikke feilsøke kildekode. |

Andre DAW-er, Mac, separat audioeffektvariant, distribuerte sender-plugins og avansert flerspillerhåndtering er ikke del av nåværende bestilling. At ett akkordspor kan brukes av andre spor er vanlig vertsruting og krever ingen egen Flysnapper-funksjon eller videre analyse.

## 2. Funksjonell signalgang

### 2.1 Pitch-to-MIDI

Audio fra et live eller innspilt kildespor kommer inn gjennom sidechain. Modulen analyserer tonehøyde og lager ordinære MIDI-hendelser: Note On, Note Off, note og velocity. Brukeren velger monofon eller polyfon gjenkjenning.

Modulen skal kunne slås av og på. Den skal anses som av når ingen audiokilde er definert i sidechain. Eksternt MIDI skal fortsatt kunne korrigeres når denne modulen er av. Bortfall eller deaktivering må ikke etterlate hengende noter.

Det er ikke valgt algoritme, velocity-modell, pitch-bend-strategi, confidence-terskler, anslags-/slippdeteksjon, legato- eller retriggerregler. Dette krever målinger og senere musikalske avklaringer. Ikke overfør Buffkillers harmoniske filter som pitchdetektor.

### 2.2 MIDI-to-MIDI

Modulen mottar vanlig MIDI fra Pitch-to-MIDI og/eller vertens MIDI-inngang. Den samme korreksjonsregelen gjelder begge kilder. Brukeren trenger ikke organisere musikere eller velge keyboardets MIDI-kanal inne i pluginen.

En separat kontrollrolle leverer akkord-MIDI. Chord Notes bruker disse pitch classes direkte. Chord Scale bruker akkordens type og grunntone sammen med brukerens akkord–skala-oppsett til å bestemme tillatte toner. Fixed Scale bruker manuelt valgt skala og grunntone uavhengig av akkordsporet. Akkordkontrollens noter skal ikke slippe ut som noter som spilles på mottakerinstrumentet.

MIDI-to-MIDI må inneholde nødvendig tilstand for å koble hver aktiv innnote til uttonen den faktisk utløste. Dette er intern Note On/Off-bokføring, ikke en ekstra funksjonsmodul mellom keyboardet og korreksjonen. Små tekniske kildeidentifikatorer kan brukes dersom de trengs for korrekt avslutning av genererte noter; de skal ikke medføre egne musikalske regler for kildene.

Korreksjonen må kunne omgås, slik at Pitch-to-MIDI også kan brukes alene. Omgåelse og kildebytte må håndtere aktive noter uttrykkelig. Den konkrete overgangsregelen skal dokumenteres og testes.

### 2.3 Brukstilfeller

| Inndata | Tillatte toner | Resultat |
|---|---|---|
| Live gitar eller innspilt audio | Korreksjon omgått | MIDI fra tonegjenkjenning til instrument på mottakerspor |
| Audio | Akkord-MIDI | Tonegjenkjenning fulgt av Chord Notes- eller Chord Scale-korreksjon |
| Audio | Skala + grunntone | Tonegjenkjenning fulgt av skalakorreksjon |
| Keyboard eller tidligere MIDI-effekter | Akkord-MIDI eller skala | Korreksjon uten pitchdetektor |
| Audio og keyboard samtidig | Akkord-MIDI eller skala | Begge leverer ordinære noter til samme korreksjonsmodul |

Det kreves ingen innebygd synthesizer. Anbefalt første instrumentwrapper har en stille audio-utgang som nødvendig vertstilpasning; lyden produseres av mottakerinstrumentet. Eventuell dry monitoring i Flysnapper er ikke bestilt. Kildeaudio kan monitoreres på sitt eget spor.

## 3. Ableton-ruting og første tekniske verifikasjon

### 3.1 Dokumentert grunnlag

Ableton beskriver at VST-instrumenter plasseres på MIDI-spor, mens audioeffekter ligger på audiospor eller etter instrumenter [R1]. Live-manualen beskriver både direkte MIDI-adressering av en plugin, valg av mottakerkanal på et multitimbralt instrument, og instrument-vocodere på MIDI-spor med innkommende sidechain-audio [R2].

Ableton dokumenterer et eget sidechain-panel for plugins med ekstern sidechain-støtte [R3]. Pluginens MIDI-utgang kan velges som kilde på et annet MIDI-spor [R4]. Abletons utviklerdokumentasjon sier at noter fra pluginens eget spor, uten MPE-modus, leveres på API-kanal 0, altså MIDI-kanal 1 [R5].

Dette støtter følgende designretning. Det beviser ikke at en ennå uskrevet JUCE/VST3-wrapper fungerer riktig i Live. Kanalfordeling, bussdeklarasjoner, hendelser, sidechain-tilstand og tidsoppførsel er eksplisitte prøver i første prototype.

### 3.2 Anbefalt standardoppsett

| Del | Oppsett som prototypen skal verifisere |
|---|---|
| Audio-kildespor | Live gitar, annet instrument eller klipp. Velges som sidechain-kilde i Live sitt pluginpanel. |
| Flysnapper-spor | MIDI-spor med Flysnapper som instrument. Vanlig keyboardtilførsel kan bruke All Ins / All Channels og passende monitorering. |
| Akkordspor | Sender til Flysnapper-sporet og videre direkte til Flysnapper-pluginen på en reservert mottakerkanal, eksempelvis 16. Ikke til Track In i dette oppsettet. |
| Mottakerinstrument | Eget MIDI-spor. MIDI From velger Flysnapper-sporet; nedre velger peker på Flysnapper-pluginens MIDI-utgang. Monitor In ved direkte livebruk. |

Den reserverte akkordkanalen er en enkel merkning av kontrollrollen i vertsrutingen. **Kanal 16 er et anbefalt konvensjonsvalg, ikke en uttrykkelig brukerfastsatt verdi.** En fast fabrikkverdi er å foretrekke framfor å kreve kanaloppsett for keyboardet. Hvis en avansert innstilling trengs, begrens den til akkordrollen.

Ikke sett Flysnapper-sporets inngangsfilter til bare akkordkanalen. Vanlig MIDI må fortsatt nå pluginen. MIDI-effekter før instrumentet kan behandle vanlig MIDI; direkte akkordtilførsel skal holdes adskilt fra denne rollen. Mottakersporets generiske Post FX er ikke en erstatning for å velge pluginens genererte MIDI-utgang [R4].

Internt genererte noter kommer fra Pitch-to-MIDI direkte inn i modul 2. De går ikke ut og inn gjennom Live sine All Ins/All Channels-velgere. Kanal 1 kan brukes som deres logiske normaltilførsel. All Ins gjelder eksterne MIDI-porter; dette endrer ikke kravet om samtidig mottak.

At et annet spor kan hente MIDI fra et akkordspor med No Output, er allerede etablert som en vertsegenskap. Det skal ikke bygges en ekstra delingsmekanisme. Standardoppsettet ovenfor bruker direkte sending for å bevare en separat akkordrolle uten en ekstra sender-plugin.

### 3.3 Ingen udokumentert egen sporvelger

Ikke lov at Flysnapper kan velge et vilkårlig Live-MIDI-spor internt og lese det uten vertsruting. VST3s ChannelContext beskriver informasjon om pluginens egen kanalkontekst; det er ingen dokumentert generell sporliste- eller MIDI-abonnementsfunksjon der [R6]. Muligheten for flere VST3-busser gir heller ingen garanti for at Live tilbyr en sekundær MIDI-sporvelger [R7].

Bruk Live sitt native sidechain-panel til audiokilden og den dokumenterte MIDI-adresseringen til akkordrollen. En egen inter-plugin sender eller Max for Live-bro er ikke standardløsningen og skal ikke innføres uten en konkret påvist blokkering.

### 3.4 Sidechain og MPE krever særskilt kontroll

Aktivert audiobuss, valgt kildespor og lyd med ikke-null amplitude er tre ulike forhold. Digital stillhet betyr ikke at kilden er frakoblet. Undersøk hvilke opplysninger Live faktisk gir den kompilerte pluginen når sidechain slås av, får No Input, eller får et stille spor. Hvis kildetilkobling ikke kan oppdages sikkert, dokumenter begrensningen og foreslå minste nødvendige UI-tilpasning før den endelige automatikkregelen fastsettes.

Reservert akkordkanal skal først testes med ordinært MIDI og MPE deaktivert. MPE kan bruke kanaler som ellers er tenkt til akkordkontroll [R5]. Full MPE-støtte er åpen og kan ikke erklæres kompatibel ved å ignorere denne konflikten. Oppdag og vis en relevant inkompatibel konfigurasjon framfor å tolke MPE-noter som akkorder.

## 4. Tillatte toner og korreksjon

### 4.1 Pitch classes og register

Det effektive tillatte tonesettet representeres som et 12-bits pitch-class-sett. I Chord Notes defineres det direkte av akkordnotene: C–E–G tillater C, E og G i alle oktaver. I Chord Scale brukes skalaen som er valgt for gjenkjent akkordtype, transponert til akkordens grunntone. Fixed Scale bruker manuelt valgt skala og grunntone. En kontrabass skal ikke flyttes opp til akkordsporets register; en piccolofløyte skal ikke flyttes ned dit.

For innnote x velges en gyldig ut-MIDI-note y som minimerer |y − x|, med y mod 12 i det tillatte settet. En allerede tillatt note beholdes. Søk må håndtere MIDI-grensene 0 og 127 korrekt. Et eventuelt brukerdefinert utområde er åpent; ikke innfør skjult registerbegrensning eller automatisk oktavtransponering.

Akkordsporets faktiske register/bass kan inngå i akkordtolkningen, men må aldri begrense korreksjonens register. Chord Notes legger ikke til impliserte toner. Chord Scale kan åpne andre toner gjennom brukerens skalavalg. Pluginen skal ikke erstatte dette valget med sin egen harmoniske anbefaling.

### 4.2 Løpsregel når to toner er like nær

Ved entydig nærmeste tillatte note brukes den, uansett løpshistorikk. Løpsregelen gjelder bare lik minsteavstand mellom to mulige uttoner:

1. To foregående toner viser stigende retning: velg den øvre kandidaten.
2. To foregående toner viser fallende retning: velg den nedre kandidaten.
3. Foregående to toner er identiske, og aktuell tone ligger nøyaktig én halvtone under: velg nedre kandidat.
4. Foregående to toner er identiske, og aktuell tone ligger nøyaktig én halvtone over: velg øvre kandidat.
5. Manglende eller ubrukelig historikk, polyfon tvetydighet eller annen uklarhet: velg øvre kandidat.

Regelen bruker bare allerede mottatt informasjon og skal ikke legge til ventetid. Historikken må ikke holdes tilbake for å se om en framtidig tone avklarer retningen. Samtidige eller overlappende kilder gir ikke grunn til å bygge en kompleks motor for separate musikere; ved tvetydig retning brukes reserven.

**Arbeidstolkning som må gjøres eksplisitt:** «foregående toner» forstås som innkommende/detekterte toner før korreksjon. Brukeren har formulert løpsregelen, men har ikke uttrykkelig avgjort før/etter korreksjon. Ikke framstill denne presiseringen som et sitat eller som endelig avklart. Regler for nullstilling av historikk og monofont legato må også avklares.

Følgende tester gjelder C-dur, med C4 = MIDI 60 som notasjon i tabellen:

| To foregående toner | Nåværende note | Korrekt ut |
|---|---|---|
| F4, G4 = 65, 67 | G#4 = 68 | A4 = 69 |
| F4, E4 = 65, 64 | D#4 = 63 | D4 = 62 |
| G4, F4 = 67, 65 | G#4 = 68 | G4 = 67 |
| G4, G4 = 67, 67 | F#4 = 66 | F4 = 65 |
| G4, G4 = 67, 67 | G#4 = 68 | A4 = 69 |
| Uavklart historikk | G#4 = 68 | A4 = 69 |

### 4.3 Tidspunkt, akkordskift og noteidentitet

Bruk det tillatte settet ved MIDI-notens faktiske beslutnings-/hendelsestid. Et gitaranslag før akkordskiftet, gjenkjent etter skiftet, korrigeres mot den nye akkorden. Ingen tilbakeberegning til anslagstid skal endre dette.

Bevar sampleposisjoner der verten gir dem. Akkordendringer inne i en blokk må ikke behandles som om de gjaldt hele blokken. Anbefalt deterministisk regel ved helt lik sampleposisjon er å samle akkordhendelsene på tidspunktet, oppdatere settet, og deretter korrigere nye noter. Dette er en implementeringspresisering som skal dokumenteres, ikke en grunn til å legge til én blokk ventetid.

Hvis Note On X blir Y, skal senere Note Off for denne innnoten avslutte den tilsvarende Y-stemmen. Ikke rekalkuler Note Off mot en nyere akkord. Dette gjelder også gjentakelser, overlapper og ulike innnoter som treffer samme ut-tone.

MIDI 1.0 uten note-ID kan ikke gi perfekt fysisk identitet for alle overlappende like noter. Velg og dokumenter en deterministisk matching-/kollisjonspolicy i dialog om de åpne reglene. Bruk VST3-note-ID der den faktisk overlever wrapper og vert; ikke anta at den finnes i JUCEs ordinære MidiBuffer.

Det er fortsatt åpent om allerede klingende noter skal beholdes, avsluttes eller flyttes når akkorden skifter, og hva som skal skje når akkordsettet blir tomt. Dette må ikke gjemmes i en tilfeldig standardregel.

## 5. Skalamoduser og oppsett per akkordtype

Brukeren skal kunne velge Chord Notes, Chord Scale eller Fixed Scale inne i MIDI-to-MIDI. Dette er ikke nye funksjonsmoduler. Chord Scale styres av en brukerredigerbar tabell med én skalatype per akkordtype. Tabellen åpnes med en flip-funksjon til GUI-ets bakside. Hver av de 50 akkordtypene i den vedlagte kilden skal ha sin egen nedtrekksmeny med samtlige skalaer nedenfor. Menyene skal ikke begrenses av antatt harmonisk kompatibilitet.

Hver rad har en anbefalt fabrikkstandard som brukeren kan endre. Oppsettet gjelder på tvers av grunntoner: m7 → Dorian gir B-dorisk ved Bm7 og E-dorisk ved Em7. Utvidede typer som m13 og m13b5 har egne valg. Alle valg lagres per plugininstans med prosjekt-/preset-tilstanden. Flip endrer bare visningen; noter og prosessering skal fortsette.

Fullstendige krav, typeoversikt og verifikasjon står i `references/CHORD_SCALE_SETTINGS.md`. Den konkrete tabellen med 50 fabrikkstandarder skal dokumenteres i implementasjonen. Den er ikke en ufravikelig harmonisk fasit eller en grunn til å be brukeren godkjenne hver standard før utvikling.

Ta med Buffkillers faktiske 18 skalaer og kromatisk skala. Denne samme listen brukes i Fixed Scale og i alle menyene på baksiden. Tallene er halvtoner over valgt grunntone; bruk modulo 12 og la korreksjonen virke i alle oktaver.

| Skala | Intervaller |
|---|---|
| Chromatic | 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11 |
| Major / Ionian | 0, 2, 4, 5, 7, 9, 11 |
| Natural Minor / Aeolian | 0, 2, 3, 5, 7, 8, 10 |
| Harmonic Minor | 0, 2, 3, 5, 7, 8, 11 |
| Melodic Minor | 0, 2, 3, 5, 7, 9, 11 |
| Dorian | 0, 2, 3, 5, 7, 9, 10 |
| Phrygian | 0, 1, 3, 5, 7, 8, 10 |
| Lydian | 0, 2, 4, 6, 7, 9, 11 |
| Mixolydian | 0, 2, 4, 5, 7, 9, 10 |
| Locrian | 0, 1, 3, 5, 6, 8, 10 |
| Whole Tone | 0, 2, 4, 6, 8, 10 |
| Major Pentatonic | 0, 2, 4, 7, 9 |
| Minor Pentatonic | 0, 3, 5, 7, 10 |
| Diminished Half-Whole | 0, 1, 3, 4, 6, 7, 9, 10 |
| Diminished Whole-Half | 0, 2, 3, 5, 6, 8, 9, 11 |
| Lydian Dominant | 0, 2, 4, 6, 7, 9, 10 |
| Altered | 0, 1, 3, 4, 6, 8, 10 |
| Phrygian Dominant | 0, 1, 4, 5, 7, 8, 10 |
| Minor Blues | 0, 3, 5, 6, 7, 10 |

Melodic Minor i referansen er ett fast sett, tilsvarende stigende/jazz melodisk moll. Ikke innfør forskjellig skala ved fallende melodier uten et nytt brukerønske.

Anbefalt: eksponer grunntone og skalatype som automatiserbare parametere, slik at endringer gjennom en låt er praktiske også uten akkordspor. Overgangsregler for holdte noter og historikk må følge de samme eksplisitte beslutningene som ved akkordskift.

## 6. Akkordgjenkjenning og grensesnitt

### 6.1 Fastlagte UI-krav

- Bevar Buffkillers formspråk: mørke paneler, kontraster, knapp-/vriderstil, typografi og tekstbehandling.
- Bevar akkordgjenkjenning fra akkordkontrollens MIDI og visningen Allowed Notes.
- Gi akkordnavnet en tydelig større fysisk flate og større skrift enn Buffkillers lille akkordetikett. Det skal være lett å lese under spilling og fungere som anvisning til utøveren.
- Vis det faktisk aktive tillatte tonesettet. I skalamodus skal valgt grunntone og skalanavn være tydelig.
- Tilby flip til baksidens komplette akkord–skala-oppsett, med leselige rader og ved behov rulling i samme visuelle stil.
- Hold tonegjenkjenning, korreksjon, audioinngangens status og MIDI-utgangens aktivitet forståelige uten utviklerterminologi.

Akkordnavnet skal beskrive akkordsporet, ikke forsøke å navngi utøverens korrigerte resultat. I Chord Scale vises også aktiv skala, eksempelvis stor «Bm7» med «B Dorian» under. Allowed Notes viser det effektive tillatte settet for valgt modus. Når gjenkjenningen er tvetydig, behold den musikalske ærligheten i Buffkiller; ikke finn på en grunntone for å tvinge fram et navn. En ukjent kombinasjon kan vises som noter. Valg mellom typekandidater og fallback ved ukjent akkord må dokumenteres fordi dette nå kan påvirke korreksjonen.

Bevar `Maj7`, liten `m` for moll, `C5` = C/G, `C5/7` = C/G/Bb, og bibliotekets regler for utelatelser og utvidelser. Referansen inkluderer m11b5, m13, 13add#9 og m13b5. Ikke gjeninnfør eldre bibliotekfeil.

### 6.2 Foreslått oppbygning, ikke vedtatt piksel-layout

Øverst foreslås et romslig akkord-/skalafelt, med primær akkordtekst omtrent 32–48 logiske piksler ved normal vindusstørrelse. Buffkiller bruker i dag 14 punkters fet akkordtekst. Tillatte toner ligger lett synlig ved hovedfeltet. Eventuelle alternative akkordnavn kan få en sekundær linje og detaljer i tooltip, uten å skjule tvetydighet.

Under dette foreslås tydelige felt for PITCH TO MIDI og MIDI TO MIDI. Ta bare inn kontroller som har en definert funksjon. Gjenbruk fargene, JUCE LookAndFeel-prinsippene og kontrolladferden beskrevet i referansevedlegget; ikke overfør Buffkillers store spektralgraf eller bassmoduler.

Final layout, vindusstørrelse, resize/skalering, språk og eksakt typografi skal godkjennes gjennom en konkret GUI-skisse senere. Buffkiller har ingen særskilt navngitt fontfamilie i koden; ikke oppgi en oppdiktet font som originalen.

### 6.3 Skille visning fra sanntidsbeslutning

Chord Scale gjør numerisk akkordtolkning til en del av korreksjonsgrunnlaget. Finn type-ID/grunntone og slå opp brukerens skala tidsriktig, uten å vente på GUI-timeren. Bygg nødvendige kandidat-/oppslagstabeller før prosessering, utenfor audiotråden. Ikke kall Buffkillers eksisterende allokerende streng-/kandidatkode direkte fra audiotråden; bevar gjenkjenningsreglene i en avgrenset numerisk representasjon.

Et konsistent snapshot av akkordtolkning, aktiv skala og effektivt tillatt sett sendes til GUI uten blokkering. Strengbygging, formattering av alternative navn og tooltip-arbeid holdes utenfor audiotråden. Endringer på baksiden overføres konsistent uten ventende GUI-lås. Oppslaget skal ikke vente på framtidige noter eller kreve en ny lydanalyseramme.

Det er tillatt at visningen oppdateres med vanlig GUI-frekvens. Det er ikke tillatt at dette legger tilsvarende ventetid på MIDI-utgangen. Om GUI er lukket skal lyd-/MIDI-oppførselen være identisk.

## 7. Latency og pitchdeteksjon

### 7.1 Brukerens akseptkrav

| Måling | Brukerens krav/ambisjon |
|---|---|
| Gitaranslag til hørbart mottakerinstrument | Over 10 ms er uakseptabelt for livebruk. |
| Samlet 5–10 ms | Akseptabelt, men ikke idealet. |
| Samlet under 5 ms | Ønsket mål for en god plugin. |
| Fra omtrent E2, 82,41 Hz | Mål om under 10 ms samlet. |
| Fra omtrent E3, 164,81 Hz | Mål om under 5 ms samlet. |

Dette er krav som må undersøkes, **ikke dokumenterte prestasjoner eller en garanti for gjennomførbarhet**, særlig ikke ved polyfoni. Ikke erstatt end-to-end-målet med hvor raskt en funksjon kjøres på CPU.

Samlet forsinkelse omfatter inngang/driver, nødvendige lyddata før en beslutning, blokk- og vertsruting, prosessering, mottakerinstrumentets anslag og audio-utgang. Ved høyttalermåling må også akustisk avstand oppgis. Buffer- og konverterforsinkelse forsvinner ikke fordi korreksjonstabellen er rask.

Driver Error Compensation retter feil rapportert innspillingsforskyvning; den reduserer ikke den fysiske forsinkelsen musikeren hører ved live avspilling [R8]. Oppgitt plugin-latency og pitchdetektorens observasjonstid er ulike størrelser og må rapporteres separat.

Én periode er omtrent 12,13 ms ved E2 og 6,07 ms ved E3. Dette er nyttig kontekst, ikke en universell matematisk nedre grense for all mulig inferens. Tidlig gjetning fra transienter/overtoner kan være mulig, men må bedømmes med feilrate og robusthet, ikke bare tidspunkt for første gjetning.

### 7.2 Forskningsretning

Ingen algoritme er valgt. Mono og poly trenger ikke dele algoritme.

| Kandidat/retning | Rolle i videre arbeid |
|---|---|
| YIN [P1] og McLeod Pitch Method [P2] | Monofone referanser for nøyaktighet, oktavfeil, støy og tidsvindu. Test korte kausale varianter, ikke anta at standardinnstillinger møter livekravet. |
| Svært tidlig monofon estimering, f.eks. Derrien [P3] | Undersøk kort observasjonstid og instrumentforutsetninger. Publiserte resultater kan ikke likestilles med vår fulle gitar–Live–synth-kjede. |
| Overtonemodell/multipitch-estimering, f.eks. Klapuri [P4] | Polyfon referanse. Den publiserte evalueringens lange rammer er ikke direkte egnet til 5/10 ms-målet; en eventuell tilpasning må måles på nytt. |
| Lokale kausale modeller | Bare aktuelle etter kontroll av nødvendig framtidskontekst, ramme/hop, modellstørrelse, CPU, datasettdekning og lisens. Offline transkripsjon er ikke i seg selv live pitch-to-MIDI. |

Kartlegg onset, pitchstabilitet, hysterese, release, nye anslag på samme tone, vibrato/bend, gitarstøy og uavhengig polyfon velocity sammen med selve pitchvalget. Et filter som bare sender når det er sikkert kan bli for sent; et filter som alltid sender tidlig kan produsere feilnoter. Begge deler inngår i evalueringen.

### 7.3 Måleopplegg

Etabler først rutingens grunnforsinkelse med kjente hendelser og et mottakerinstrument med raskt, målbart anslag. Mål deretter pitchdetektoren separat og til slutt hele kjeden på brukerens relevante Windows-/audiooppsett.

Test minst mono E2, E3 og høyere toner, kromatiske løp begge veier, gjentatte toner, svake/sterke anslag, legato, forskjellige gitarstrenger/klangfarger og relevante akkorder. Polytester må omfatte samtidige og forskjøvede anslag, tette intervaller, oktaver og svake toner under sterkere toner. Rene sinusfiler er nyttige kontroller, men utilstrekkelig dokumentasjon for gitarbruk.

Rapporter sample rate, bufferstørrelse, driver/interface, Live-versjon, maskinvare, modell/innstillinger, tilgjengelig polyfoni og eksakt målegrense. Oppgi median, P95/P99 og største observerte forsinkelse sammen med falske anslag, manglende noter, oktavfeil og release-/retriggerfeil. CPU må vurderes som blokkfrist og høyeste belastning, ikke bare gjennomsnitt.

Registrer tid til **første korrekte og brukbare ut-note**. En tidlig feilnote som senere byttes er en feil, ikke en bestått lavlatencyhendelse. Målinger med korrigeringsmotoren avslått må avsløre om akkordfilteret bare maskerer pitchfeil. Ingen releasepåstand om generelt under 10 ms kan bygge bare på et gjennomsnitt eller et syntetisk signal.

Hvis polyfoni ikke møter brukerens krav, legg fram målte grenser og realistiske alternativer. Ikke øk analysetiden til 30–100 ms eller fjern polyfoni som skjult produktendring.

## 8. MIDI-tilstand og åpne musikalske valg

Følgende er nødvendige korrekthetsegenskaper: ingen hengende noter; ingen rekalkulering av Note Off mot ny akkord; velocity-zero Note On behandles som Note Off; kontrollerte overganger ved transport, bypass og frakobling; ingen ubegrenset køvekst; ingen akkordnoter lekket til utinstrumentet.

Andre MIDI-data skal ikke bare kastes eller omtolkes uten uttrykkelig policy. VST3 har egne hendelser/parameterrepresentasjoner og er ikke en transparent rå MIDI-byteledning [R9]. Test både JUCE-adapteren og den kompilerte pluginens inn-/utgang.

| Åpent valg | Hvorfor det må avgjøres |
|---|---|
| Holdt tone ved akkord-/skalaskift | Beholde, avslutte eller flytte gir forskjellig musikalsk resultat. |
| Tomt akkordsett | Pass-through, stillhet eller siste akkord gir svært forskjellig oppførsel ved pauser og oppstart. |
| CC64 på akkordkontroll | Om pedal skal forlenge det tillatte settet. Må skilles fra utøverens pedal. |
| CC64 på vanlig MIDI | Samspill mellom sustain, Note Off-bokføring og kolliderende uttoner. |
| Flere innnoter på samme uttone | Retrigger, referansetelling og slippadferd må være deterministisk. |
| Overlappende like innnoter | Note-ID når tilgjengelig, ellers avtalt matching. |
| Løpshistorikk | Før/etter korreksjon, nullstilling, legato og tvetydige samtidige hendelser. |
| Utområde | Eventuell brukergrense utover MIDI 0–127; ingen skjult registerflytting. |
| Velocity | Detektorens nivå/transientmodell, kurve, terskel, dynamikk og polyfon fordeling. Anbefalt å bevare ekstern notevelocity. |
| Pitch bend/uttrykk | Bends kan gjøre en tillatt note hørbart utenfor settet; velg en tydelig musikalsk strategi. |
| CC, pressure, MPE og kanaler | Hva som støttes/bevares/endres, separat for kontrollrolle og vanlig MIDI. |
| Bypass, panic, transport og kildebytte | Nøyaktig avslutning/reset, uten å stoppe noter som ikke tilhører den aktuelle kilden unødvendig. |
| UI-detaljer | Størrelse, språk, skalerbarhet og kontroller etter at nødvendig funksjon er kjent. |
| Flertydig/ukjent akkord i Chord Scale | Valg av typekandidat og fallback når type/grunntone ikke kan bestemmes må være dokumentert og testet. |

Disse valgene blokkerer ikke en isolert routingprototype eller måling av detektorkandidater. En prototype kan ha en tydelig dokumentert testpolicy, men denne skal ikke bli en umerket sluttproduktstandard. Samle bare de beslutningene brukeren faktisk må ta, med konkrete musikalske eksempler når de blir aktuelle.

## 9. Teknisk gjennomføring og gjenbruk

Bruk en separat kodebase og nye stabile plugin-ID-er, parameter-ID-er og tilstandsskjema. Anbefalt arbeidsmappe er `D:\Flysnapper`. Ikke endre, oppgrader eller installer over `D:\Buffkiller` eller `Buffkiller.vst3`.

C++/JUCE/CMake er etablert utgangspunkt. Buffkiller-byggeren låser JUCE til `8.0.16-security`, commit `ea77444750de45e036e0279bb0291144bf8e3688`. Dette er en kontrollert referanse, ikke en påstand om at en annen versjon aldri kan være riktig. Eventuelle endringer må begrunnes og beholde Unicode-sikkerheten.

Gjenbruk relevant bygging, verktøyoppdagelse, tester, stibehandling, atomiske GUI-snapshots, skala-/akkorddata og visuell kode etter inspeksjon. Bevar lisens- og opphavsnotiser ved faktisk kodegjenbruk. Ikke gjenbruk Buffkillers audioeffekt-wrapper ukritisk: den er ikke et instrument og har ikke MIDI-utgang. Detaljer står i vedlegget.

Hold audiotråden fri for unødvendige heap-allokeringer, ventende låser, fil-/nettverkstilgang, konsollskriving, GUI-kall og oppbygging av strenger/oppslagstabeller. Forhåndsalloker med eksplisitte kapasiteter og definert overflow-oppførsel. Tunge beregninger på bakgrunnstråd må fortsatt ha en avgrenset, målt vei fram til en tidsriktig MIDI-hendelse; en tråd flytter ikke automatisk bort latency.

Bevar sampleoffsets, prosesser blokkinterne kontrollendringer riktig, og test varierende blokkstørrelser og sample rates. Ikke legg en hel blokk i kø bare for å forenkle modulgrensen. Oppgi ærlig eventuell algoritmisk delay og ikke bruk rapportert 0 samples som bevis for null pitchforsinkelse.

Tilstandslagring skal bevare innstillinger og åpne riktig etter gjenåpning, uten å gjenopplive gamle aktive noter. Live eier sporrutingen; plugin-state må ikke late som den kan lagre en egen autoritativ liste over Live-spor.

## 10. Faser og testkrav

### Fase A – vert og ruting

Lag en minimal, navngitt Flysnapper VST3 med ny identitet. Undersøk minst:

1. Instrumentklassifisering og plassering på MIDI-spor.
2. Sidechain-buss som Live faktisk viser og leverer audio til; av/på, stille kilde og kildeendring.
3. Vanlig track-MIDI og direkte akkord-MIDI på separat kanal, uten sammenblanding.
4. MIDI fra foranstående MIDI-enhet og keyboard; samtidige internt genererte testnoter.
5. Pluginens MIDI-utgang til mottakerspor, med sampleoffset og normal Note On/Off-livssyklus.
6. Lagre/gjenåpne sett, flere instanser uten krysskobling, play/stop, loop og seek.
7. Målt grunnforsinkelse og dokumentert MPE-modus.

Lever et kort vertsresultat med faktiske tester, versjoner og resterende usikkerhet. Om en antagelse feiler, løs den avgrensede tekniske årsaken før DSP-arbeidet utvides.

### Fase B – MIDI-to-MIDI og grunnleggende UI

Implementer fastlagte korreksjonsregler, skalaer, akkordmasker, brukerens akkord–skala-tabell og intern notebinding. Lag en konkret GUI-skisse med stor akkordvisning, Buffkiller-stil og flip til baksidens 50 skalamenyer. Dokumenter fabrikkstandardene og test lagring/gjenoppretting av alle valg. Avklar de øvrige musikalske overgangene før denne delen erklæres ferdig.

### Fase C – monofon gjenkjenning og måling

Sammenlign få relevante kausale kandidater mot det samme datasettet og hele latencybudsjettet. Avgjør onset/release og velocity med dokumenterte resultater. Integrer valgt løsning uten å endre eksternt MIDI sin korreksjonsregel.

### Fase D – polyfon gjennomførbarhet og ferdigstilling

Demonstrer polyfon nøyaktighet, uavhengige hendelser og realistisk latency før stor integrasjon. Begge moduser inngår i produktmålet. En tidlig mono-prototype er ikke ferdig oppfyllelse av bestillingen.

### Obligatorisk verifikasjon gjennom fasene

| Område | Meningsfulle kontroller |
|---|---|
| Korreksjon | Tillatte noter uendret; globalt nærmeste kandidat; alle pitch classes, registre og MIDI-grenser; de seks tie-eksemplene; kromatisk identitet. |
| Akkordkontroll | Duplikater i flere oktaver, Note Off som ikke fjerner fortsatt holdt pitch class, samtidige akkordskift, ingen kontrollnoter i output. |
| Hendelser | Mapping over akkordskift, overlapp, kollisjoner, velocity 0, sustain etter valgt policy, panic, bypass og kildebortfall. |
| Samtidige kilder | Genererte og eksterne noter behandles likt; avslutning av pitchmodulen skader ikke ekstern note uten grunn. |
| GUI | Stor leselig akkord, korrekt Allowed Notes, lange/tvetydige navn, ukjent akkord, skalamodus, GUI lukket/åpent uten endret MIDI-resultat. |
| Akkord–skala-oppsett | Alle 50 typer og alle 19 skalaer; brukervalg overstyrer standard; egne valg for utvidede typer; alle 12 grunntoner; Chromatic; lagre/gjenåpne; isolerte instanser; flip uten noteavbrudd. |
| Realtime | Allokeringskontroll, avgrensede køer, verste blokkbelastning, ingen GUI- eller fillås i prosessering. |
| Faktisk VST3 | Last den kompilerte modulen i testvert; bekreft busser, event inn/ut, tilstand, reset og wrapperadferd. Engine-tester alene er utilstrekkelige. |
| Ableton | Egen end-to-end-test i Live 12 Suite. Testvert erstatter ikke denne. |
| Windows-pakke | Ren utpakking, Unicode-stier, eksisterende byggemiljø, manglende verktøy med klar feilmelding, installasjon stoppet ved testfeil. |

Tilpass Buffkillers test-før-installasjon-prinsipp. Ikke arve navn eller avkryssing uten å utføre tilsvarende Flysnapper-kontroller. Ikke senk toleranser, fjern tilfeller eller svekk testene bare for å få grønt bygg.

## 11. Leveranser og kommunikasjon

Brukeren har omfattende Ableton-erfaring. Ikke be ham bevise grunnleggende rutingmuligheter eller lære ham programmets grunnbegreper om igjen. Forklar bare oppsettet som den konkrete Flysnapper-versjonen krever.

Lever hele ZIP-pakker med kilde, låste avhengigheter/henvisninger, byggeskript, tester, kort norsk installasjonsveiledning og tydelig versjon. Ingen oppskrift på å kopiere inn enkelte erstatningsfiler. Installer først etter at nødvendige tester har bestått; behold gjenopprettingsmulighet og unngå dupliserte gamle pluginfiler.

Oppgi ved hver milepæl hva som er implementert, hva som faktisk er testet, målte begrensninger og hvilke få beslutninger som gjenstår. En simulert Windows-test er ikke en MSVC-kjøring; en kompilert VST3-test er ikke automatisk en Live-test; en vellykket build er ikke bevis for musikalsk nøyaktighet.

## 12. Kilder og dokumentasjonsstatus

Produktkravene over kommer fra brukerens prosjektbeskrivelse og senere presiseringer fram til 3. november 2026. Buffkiller-kilden er den vedlagte, inspiserte pakken. Nettkildene ble undersøkt i designarbeidet 2.–3. november 2026; sentrale Ableton-rutingskilder er kontrollert 3. november. Nettdokumentasjon erstatter ikke den planlagte vertstesten.

### Vert og pluginformat

- **[R1] Ableton Live 12 Manual – Using Plug-Ins:** https://www.ableton.com/en/live-manual/12/using-plug-ins/ – sporplassering og pluginformat.
- **[R2] Ableton Live 12 Manual – Routing and I/O:** https://www.ableton.com/en/live-manual/12/routing-and-i-o/ – særlig 17.5.2.4, 17.5.2.6 og 17.5.2.7: direkte instrumentadressering, kanaler og sidechain til instrument-vocoder.
- **[R3] Ableton – Sidechaining a third-party plug-in:** https://help.ableton.com/hc/en-us/articles/209775325-Sidechaining-a-third-party-plug-in – native sidechain-panel.
- **[R4] Ableton – Accessing the MIDI output of a VST plug-in:** https://help.ableton.com/hc/en-us/articles/209070189-Accessing-the-MIDI-output-of-a-VST-plug-in – valg av pluginutgang og direkte mottakerkanal; også begrensning ved vanlig inter-track kanalbevaring.
- **[R5] Abletons utviklerdokumentasjon – Supporting MPE with plugins in Live:** https://github.com/Ableton/ableton.github.io/blob/main/plugins/mpe-support-plugins.md – vanlig track-input, MPE-kanaler og signalering.
- **[R6] Steinberg VST3 – ChannelContext::IInfoListener:** https://steinbergmedia.github.io/vst3_doc/vstinterfaces/classSteinberg_1_1Vst_1_1ChannelContext_1_1IInfoListener.html – metadata om pluginens kontekst; ikke generell kontroll over andre spor.
- **[R7] Steinberg VST3 – Multiple Dynamic I/O:** https://steinbergmedia.github.io/vst3_dev_portal/pages/Technical%2BDocumentation/Change%2BHistory/3.0.0/Multiple%2BDynamic%2BIO.html – formatets bussmodell; vertsbruk må verifiseres.
- **[R8] Ableton – Driver Error Compensation FAQ:** https://help.ableton.com/hc/en-us/articles/115000234830-Driver-Error-Compensation-FAQ – skillet mellom innspillingsforskyvning og live avspillingslatency.
- **[R9] Steinberg VST3 – About MIDI:** https://steinbergmedia.github.io/vst3_dev_portal/pages/Technical%2BDocumentation/About%2BMIDI/Index.html – representasjon av MIDI-relaterte data i VST3.

### Algoritmereferanser, ikke ferdige implementeringsvalg

- **[P1] de Cheveigné og Kawahara (2002), YIN, a fundamental frequency estimator for speech and music:** https://doi.org/10.1121/1.1458024 — forfatterartikkel, også tilgjengelig fra https://iro.umontreal.ca/~pift6080/H09/documents/papers/yin_pitch_tracker.pdf
- **[P2] McLeod og Wyvill (2005), A Smarter Way to Find Pitch:** https://www.cs.otago.ac.nz/graphics/Geoff/tartini/papers/A_Smarter_Way_to_Find_Pitch.pdf
- **[P3] Derrien (2014), A Very Low Latency Pitch Tracker for Audio to MIDI Conversion:** https://www.dafx14.fau.de/papers/dafx14_olivier_derrien_a_very_low_latency_pitch_.pdf
- **[P4] Klapuri (2006), Multiple Fundamental Frequency Estimation by Summing Harmonic Amplitudes:** https://ismir2006.ismir.net/PAPERS/ISMIR06125_Paper.pdf

## 13. Hva denne handoveren har og ikke har verifisert

Gjennomført: kravsamling, kontroll av sentrale primærkilder, inspeksjon av Buffkillers kilde-/byggepakke, uttrekk av skalaer/GUI-konvensjoner/akkordbibliotek og integritetskontroll av handoverpakken.

Ikke gjennomført: implementering av Flysnapper, Windows-/MSVC-bygg av Flysnapper, kompilert VST3-vertstest, routingtest i Live eller måling av pitch-to-MIDI/end-to-end-latency. Disse er utviklingsoppgaver i fasene over. Buffkillers historiske logger er referanser til det tidligere prosjektet og skal ikke brukes som Flysnapper-testresultater.
