# Flysnapper – start her

Dato: 3. november 2026. Bestiller: Olav Lægreid.

**Oppdatert: spesifikasjon 2.** Omfatter nå brukerens skalaoppsett for alle 50 akkordtyper på en bakside med flip-funksjon. Denne pakken erstatter spesifikasjon 1 fra samme dato.

Dette er en overlevering for utvikling av **Flysnapper**, en ny Windows x64 VST3-plugin for Ableton Live 12 Suite. Pakken inneholder krav, tekniske undersøkelser, åpne valg og den uendrede Buffkiller-referansen. Den inneholder ikke en ferdig Flysnapper-plugin.

## Til brukeren

Last denne ZIP-pakken opp i Codex. Hvis Codex trenger utpakkede filer, pakk ut hele pakken og gi den tilgang til mappen. Du trenger ikke hente enkeltdeler fra Buffkiller eller forklare prosjektet på nytt.

Følgende beskjed kan følge pakken:

> Utvikle Flysnapper etter vedlagte handover. Les START_HERE.md, hele Flysnapper_Codex_Handover.md og references/BUFFKILLER_REFERENCE.md før du endrer kode. Buffkiller er et separat, ferdig produkt og skal forbli urørt. Begynn med den avgrensede VST3-/Ableton-verifikasjonen beskrevet i handoveren. Fortsett med det som kan gjennomføres uten nye musikalske beslutninger. Merk prototyper og uverifiserte antagelser tydelig. Ikke velg åpne musikalske regler på mine vegne, og ikke lov oppnådd latency uten målinger. Lever komplette pakker og løs tekniske problemer selv; ikke be meg redigere eller feilsøke kildekode.

## Til Codex

Les i denne rekkefølgen:

1. `Flysnapper_Codex_Handover.md` – gjeldende spesifikasjon, med kravstatus og gjennomføringsplan.
2. `references/BUFFKILLER_REFERENCE.md` – hva som faktisk er funnet i referansekoden, hva som skal gjenbrukes, og hva som ikke tilhører Flysnapper.
3. `references/CHORD_SCALE_SETTINGS.md` – fastlagt oppsett på baksiden, alle akkordtyper, lagring og testkrav.
4. `references/Buffkiller_1.0.0_Komplett_Versaler.zip` – komplett, uendret kilde-/byggepakke. Pakk den ut som referanse; ikke kjør installasjonsskriptet for å installere Flysnapper.

De nyeste kravene har forrang foran den opprinnelige handoveren fra Buffkiller. Særlig gjelder dette pitch classes, samtidig MIDI fra keyboard og tonegjenkjenning, bare to funksjonsmoduler, obligatorisk akkordvisning med større plass, og brukerens skalavalg per akkordtype. Brukerens redigerbare tabell erstatter behovet for å utlede én universelt riktig skala fra hver akkord.

`SHA256SUMS.txt` inneholder kontrollsummer for pakkens øvrige filer. Referansearkivet er bevart byte for byte. Eventuelle historiske testlogger inni det gjelder Buffkiller; de dokumenterer ingen testing av Flysnapper.

## Første konkrete resultat

Lag først en liten, testbar Flysnapper VST3-prototype som avklarer sporplassering, audio-sidechain, separate roller for vanlig MIDI og akkord-MIDI, samtidig mottak, MIDI-utgang og lagring/gjenåpning i Live. Bruk genererte testhendelser til å undersøke MIDI-utgangen før en pitchdetektor finnes. Ikke invester i en stor polyfon detektor før rutingen er bekreftet og latencymålingen er etablert.

Hvis Windows eller Live ikke finnes i utviklingsmiljøet, fullfør automatiserte deler og lever en ferdig bygbar/testbar pakke med en kort avgrenset vertstest. Beskriv nøyaktig hva som er og ikke er verifisert. Ikke framstill en egen testvert som en Ableton-test.
