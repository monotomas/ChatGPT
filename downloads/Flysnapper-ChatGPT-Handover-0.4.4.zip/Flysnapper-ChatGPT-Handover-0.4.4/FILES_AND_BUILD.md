# Kildehenvisninger og videre arbeid

## Hvor ligger logikken?

| Fil i repository / KILDEUTVALG | Ansvar |
|---|---|
| Source/Core/MusicData.cpp,h | 52 akkordtyper,38 skalaer, fabrikkverdier, gjenkjenning og GUI-navn/rekkefølge |
| Source/Core/Reference/* | Bevarte Buffkiller-definisjoner, navngiving og stavemåte |
| Source/Core/MidiEngine.cpp,h | Nærmeste tillatte tone, råhistorikk, FIFO, referanser, sustain, kapasitet |
| Source/PluginProcessor.cpp,h | JUCE/VST3-adapter, MIDI-kanaler, transport og tilstand |
| Source/PluginEditor.cpp,h | Spillevindu, hjelp, firekolonneoppsett og ID-sikre skalamenyer |
| Tests/CoreTests.cpp | Uttømmende musikk-/motorprøver og akkordtone-rekkefølge |
| Tests/PluginTests.cpp | Faktisk prosessor/GUI, menybindinger, etiketter og bilder |
| Tests/MidiOnlyProcessorTests.cpp | Tidsordnede MIDI-strømmer og rå rapporter |
| Tests/Vst3HostTests.cpp | Faktisk kompilert VST3 og direkte SDK-prøver |
| Tools/midi_only_evidence.py | Binder rapporter, CTest, modul og 21 utvalgte prosjektfiler |
| Tools/package_windows.py | Verifisert Windows-pakke |
| Tools/windows_installer.ps1 | Installasjon, erstatning og gjenoppretting |
| Tools/verify_windows_install.py | Faktisk privat PS/BAT-installasjonsprøve |
| Tools/publish_windows_delivery.py | Kontrollert publisering gjennom Git |
| build_plugin.py / CMakeLists.txt | Bygging og native validering |
| .github/workflows/windows.yml | Windows CI, Unicode-byggebane og installasjon |

`chordToneNamesInRootPosition(mask,root,typeIndex)` er GUI-only og kan
allokere. Den kjøres fra editorens timer, ikke fra audiotråden. Den bruker
snapshotets allerede gjenkjente rot/type og foretar ikke ny tolkning.
Registrenes indekser, stabile akkord-/skala-ID-er og lagrede parametre
skal skilles fra presentasjonsrekkefølgen.

## Hva kildeutvalget inneholder

`KILDEUTVALG/` bevarer aktuelle kodefiler og de fire native testene fra
den publiserte runtime-kilden 57240a3, byte for byte. Proveniensen og
de21 utvalgte filhashene ligger i `ORIGIN.json` og testmanifestene.
Det er ikke et komplett byggerepository: historiske lydopptak, hele
Python-testgrunnlaget, avhengigheter og historiske dokumentarkiver er
utelatt for å holde opplastingen kompakt. Hent fullt repository eller
full kildepakke før et komplett bygg eller hele Python-suiten kjøres.

Den komplette kildepakken ligger i Windows-leveransens `Source/`-mappe.
Den inneholder omfattende historiske lydtestdata som ikke trengs for
å forstå dagens MIDI-versjon.

## Full checkout

Repository: https://github.com/monotomas/ChatGPT

- Kompilert runtime-kilde: 57240a38575f3d453a69b6c5d90a34aefb56a219.
- Senere dokumentasjonsbackup: c6f01a9a4c63d594a66b200d094c7d16c8067d4d.
- Relevante kodefiler er like mellom disse; den senere backupen har sluttbevis.
- JUCE 8.0.16-security er låst til ea77444750de45e036e0279bb0291144bf8e3688.

Eksisterende checkout bør inspiseres og brukerendringer bevares før et
versjonsbytte. En ny instans har ikke automatisk det gamle skymiljøets
filer, prosesser eller tilganger. Linux-bygget er ikke en Windows-plugin.

I et fullt kompatibelt Linux-utviklingsmiljø beskriver prosjektet:

```sh
bash Tools/cloud_setup.sh
source Tools/cloud_env.sh
CMAKE_BUILD_PARALLEL_LEVEL=2 bash Tools/cloud_validate.sh
python -m unittest discover -s Tests -p 'test*.py'
```

Bruk dette når nytt arbeid krever nye kontroller. Den leverte 0.4.4 er
allerede kontrollert. `cloud_validate.sh` eier bygge-/testlåsen
`build/native-release/.flysnapper-build.lock` og midlertidig Xvfb97.
Manuelle CMake/Ninja-kall bruker samme lås; ikke legg en ny ytre lås rundt
skriptet. Det trengs ingen vedvarende tjeneste for pluginen.

Windows bygges og testes separat med prosjektets Windows-verktøy/CI.
En levering bør binde eksakt kildecommit, modul, rå MIDI-resultater,
installasjonsprøve og ZIP-hash. Byggesuksess alene er ikke en måling av
Ableton-ruting eller fysisk end-to-end-latency.
