# Gjeldende funksjonsregler

Dette er en samlet beskrivelse av den leverte 0.4.4-baselinen.

## MIDI-kanaler og korreksjonsmodi

Kanalnumre her er 1-baserte: spille-MIDI **1** (statuskanal 0) og
akkordkontroll **16** (statuskanal 15). Kanalene 2–15 videresendes uten
tonekorreksjon. Kanal 16 konsumeres med mindre **Chord MIDI Through** er på.

- **Chord Tones Only**: korriger til faktisk holdte toner i en gjenkjent akkord.
- **Chord-Scale Assignment**: gjenkjenn akkordtype og bruk dens egen valgte
  skala, transponert til akkordens grunntone.
- **Fixed Scale**: bruk valgt grunntone og skala uavhengig av akkordsporet.
- **Note Correction** av: nye spilletoners tonehøyde forblir uendret;
  akkordlyttingen og bindingene for senere Note Off fortsetter.

Ingen gjenkjent akkord gir **Chromatic** i begge akkordavhengige moduser.
Dette omfatter tomt akkordinput, én unik toneklasse og uidentifiserte sett
med flere toner. Gjenkjente power-dyader er fortsatt gjenkjente akkorder.
Det legges ikke til en skjult union av akkordtoner og valgt skala.

## Akkordgjenkjenning

De 50 korrigerte Buffkiller-typene er beholdt, og CMaj13#11 og CMaj9#11
er lagt til som typeindeks 50 og 51. Toner som holdes mellom akkorder,
inngår i neste analyse. Fraværende grunntoner blir ikke funnet på.
En støttet tolkning krever bass i grunntone, ters eller kvint etter
typens definisjon. Uttrykkelig støttede utelatelser følger biblioteket.

Første tolkning velges etter færrest uttrykkelige utelatelser, så den
direkte definisjonen foran variant med ekstra none, så rotbass foran
tersbass foran kvintbass. Resterende likhet følger den bevarte
bibliotek-/grunntonerekkefølgen. Alternative navn kan vises samtidig.
Korreksjon og akkordtonelinje følger den første tolkningen.

## Nærmeste tone og nøyaktig tie-break

Nærmeste tillatte MIDI-note i 0–127 velges. En entydig nærmeste note vinner.
Bare ved lik avstand brukes disse reglene, uten å vente på framtidige noter:

La P være forrige **rå innnote**, Q rå innnote før P, og N aktuell innnote.
N inngår ikke i paret som måler retningen.

| Tilstand | Valg ved lik avstand |
|---|---|
| P > Q | Øvre tillatte note |
| P < Q | Nedre tillatte note |
| P = Q og N = P − 1 | Nedre tillatte note |
| P = Q, øvrige tilfeller | Øvre tillatte note |
| Manglende eller tvetydig historikk | Øvre tillatte note |

Eksempler med C-dur som tillatt skala:

- Rå 65,67 og aktuell68 gir69.
- Rå 71,69 og aktuell68 gir67.
- **Rå67,65 og aktuell68 gir67**, selv om aktuell tone går opp fra65.
- Rå61,62 og aktuell61 gir62; korrigerte historiske toner skal ikke brukes.

Historikken holdes per intern kilde × MIDI-kanal. Vanlig legatooverlapp,
holdte toner eller sustain sletter ikke historikken. Flere positive
Note On på samme sample i samme strøm, også duplikater, gjør tidspunktet
tvetydig: oppover som reserve, uten å så en ny ordnet historikk.

Innstillingsendring, Panic og kapasitetssikring nullstiller historikk.
CC120/123 nullstiller sin kilde/kanal; kildestopp nullstiller sin kilde.
Slik opprydding inne i en samtidig gruppe beholder gruppens tvetydighet.
En annen kilde eller kanal må ikke slette musikeren sin melodihistorikk.

## Nye anslag og Note Off

Et nytt spilleanslag som får samme utgående tone som en aktiv tone,
sender **Note Off med velocity0, deretter ny Note On med ny velocity,
på samme sample-offset**. Dette skal gi et nytt rytmisk anslag.

Hver innnote beholder sin opprinnelige utgående binding. Gjentatte like
innnoter slippes FIFO. Referansetelling gjør at en eldre Note Off ikke
kutter en nyere stemme som fortsatt holdes; siste binding slipper tonen.
Påbegynte toner retunes ikke ved akkord-/skala-/modusbytte.
Den syntetiske rutingtesten har lav kollisjonsprioritet.

CC64-sustain håndteres internt per kilde/kanal og konsumeres. CC120/123
slipper den aktuelle kildens/kanalens stemmer uansett sustain. CC121
nullstiller sustain og videresendes. Forwardede CC66/69 spores for global
pedalopprydding. Panic og kapasitetssikring rydder opp i noter/pedaler.

Motoren har 512 innbindinger og 4096 utgående plasser. Overløp gir
avgrenset opprydding og synlig feiltilstand; eksplisitt reset/Panic
aktiverer igjen. Kapasitet utvides ikke på audiotråden.

## Transport

Eksplisitt stopp fra verten gir **Chromatic i alle tre moduser**, uten å
endre lagret/automatisert modus, rot eller skala. Et faktisk skifte fra
avspilling til stopp utfører opprydding: aktive noter og pedaler slippes,
og akkordgrunnlaget tømmes. Nye toner som startes mens transporten er
stoppet, beholder sine Note Off-bindinger når avspilling eller valgte
innstillinger gjenopptas. Avspilling tar igjen i bruk de lagrede valgene.

Manglende playhead/posisjon er ukjent, ikke stopp. En oppgitt ikke-endelig
sekundverdi behandles også som ukjent. JUCEs VST3-wrapper kan materialisere
NaN-klokke ved null SDK ProcessContext; dette er håndtert. JUCEs testvert
kan selv syntetisere gyldig stoppmetadata fra manglende informasjon
oppstrøms; dette kan ikke skilles fra en gyldig rapportert stopp via
pluginens offentlige API. Testene merker tilfellene separat.

## Visning og oppsett

- Én unik toneklasse vises for eksempel **G (single note)**, også ved
  oktavduplikater. Durtreklangen vises **G Major**.
- Spillevinduets **Chord tones** viser grunnstilling: rot, ters/sus, kvint,
  eventuell sekst, septim, none, 11 og 13. G13: **G B D F A C E**.
- Altererte toners rolle avgjør rekkefølgen: #9 følger septimen, #11 er
  en ekstensjon, b5/#5 er kvinter, og C6/9 viser C E G A D.
- Bare mottatte toneklasser vises. Utelatte toner legges ikke til.
  Listen følger første gjenkjente tolkning; ukjente sett beholder nøytral
  toneklasserekkefølge. Grunnstilling endrer ikke MIDI-utgangen.
- Baksiden har 52 uavhengige tilordninger i fire kolonner 14/12/12/14.
  C5 følger Cm. C7b13 avslutter andre kolonne; C7sus4 starter tredje.
- Alle kolonner passer i bredden ved 1040×760; rulling er loddrett.
- Alle 38 skalaer er valgbare per rad. Kompatible valg står først.
  Manglende akkordtoner navngis med vanlig advarselsfarge; ingen spesielle
  unntak gjelder 13#9-typene. Begge bruker Chromatic som fabrikkvalg.
- Nye instanser og Reset all 52 bruker fabrikkverdier. Lagrede instanser
  beholder egne tilordninger. Stabile ID-er og parameterindekser beholdes;
  visningsrekkefølge er separat fra registrenes lagringsrekkefølge.
