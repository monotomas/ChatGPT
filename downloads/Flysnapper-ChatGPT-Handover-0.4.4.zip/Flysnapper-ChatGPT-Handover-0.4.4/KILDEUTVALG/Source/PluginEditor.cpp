// SPDX-License-Identifier: AGPL-3.0-or-later
#include "PluginEditor.h"
#include "PluginProcessor.h"
#include "Core/MusicData.h"
#include <algorithm>
#include <cmath>
#include <string_view>

namespace {
const juce::Colour background{0xff141b22},panel{0xff1d2731},border{0xff344351};
const juce::Colour text{0xffedf2f5},muted{0xff9badbb},orange{0xffffb15d};
const juce::Colour blue{0xff5daeff},green{0xff58d7bb};
constexpr const char* noteNames[]{"C","Db","D","Eb","E","F","F#","G","Ab","A","Bb","B"};
constexpr const char* familyNames[]{"Chromatic","Diatonic modes","Melodic Minor modes","Bebop",
    "Harmonic Minor modes","Harmonic Major modes","Diminished","Whole Tone","Major Pentatonic","Minor Pentatonic","Minor Blues"};
constexpr int familyCount=int(sizeof(familyNames)/sizeof(familyNames[0]));
constexpr const char* mappingOrder[4][14]{
    {"major","sus2","sus4","major_sixth","six_nine","major_seventh","major_seventh_sharp5",
     "major_seventh_sharp9","major_seventh_sharp11","major_ninth","major_ninth_sharp11",
     "major_eleventh","major_thirteenth","major_thirteenth_sharp11"},
    {"dominant_seventh","power_seventh","dominant_sharp5","dominant_sharp5_sharp9",
     "dominant_sharp5_flat9","dominant_sharp9","dominant_sharp11","dominant_flat5",
     "dominant_flat5_sharp9","dominant_flat5_flat9","dominant_flat9","dominant_flat13"},
    {"dominant_sus4","dominant_sus4_flat9","dominant_ninth","ninth_sharp11","ninth_sus4",
     "dominant_eleventh","dominant_thirteenth","thirteenth_sharp9","thirteenth_add_sharp9",
     "thirteenth_flat9","thirteenth_sus4","thirteenth_sus4_flat9"},
    {"minor","power","minor_sixth","minor_seventh","half_diminished","minor_ninth",
     "minor_eleventh","minor_eleventh_flat5","minor_thirteenth","minor_thirteenth_flat5",
     "minor_major_seventh","minor_major_ninth","minor_major_thirteenth","diminished_seventh"}
};
constexpr const char* mappingHeadings[]{"MAJOR","DOMINANT 1","DOMINANT 2","MINOR"};
constexpr const char* assignmentTip="Tool tip: This VST3 loads as an instrument. On a receiving MIDI track, set MIDI From to Flysnapper's track, then choose Flysnapper in the lower selector. Put the destination instrument there and enable monitoring. Automate Note Correction on/off while leaving the Flysnapper device enabled in Live.";
void label(juce::Label& l,const juce::String& s,float size=14,juce::Colour colour=text,bool bold=false){
    l.setText(s,juce::dontSendNotification);
    l.setFont(juce::Font(juce::FontOptions(size,bold?juce::Font::bold:juce::Font::plain)));
    l.setColour(juce::Label::textColourId,colour);l.setMinimumHorizontalScale(1.f);
    l.setBorderSize({0,0,0,0});l.setEditable(false,false,false);
}
juce::String namesFor(uint16_t mask){
    juce::StringArray names;for(int n=0;n<12;++n)if(mask&(1u<<n))names.add(noteNames[n]);
    return names.isEmpty()?juce::String("none"):names.joinIntoString("  ");
}
void populateScales(juce::ComboBox& box,uint16_t chordMask){
    box.clear(juce::dontSendNotification);
    const auto& definitions=flysnapper::scaleDefinitions();
    bool first=true,previousCompatible=true;int previousFamily=-1;
    for(int index:flysnapper::orderedScaleIndices(chordMask)){
        const auto& definition=definitions[size_t(index)];
        const bool compatible=flysnapper::scaleContainsChord(index,chordMask);
        if(chordMask!=0){
            if(first||compatible!=previousCompatible)
                box.addSectionHeading(compatible?"Scales with all chord tones":"Chord tones outside scale");
        }else if(definition.familyOrder!=previousFamily){
            const int family=std::clamp(definition.familyOrder,0,familyCount-1);box.addSectionHeading(familyNames[family]);
        }
        box.addItem((compatible?juce::String{}:juce::String("! "))+juce::String::fromUTF8(definition.name),index+1);
        previousCompatible=compatible;previousFamily=definition.familyOrder;first=false;
    }
    box.setScrollWheelEnabled(false);
}
void drawPanel(juce::Graphics& g,juce::Rectangle<int> r,juce::Colour accent){
    g.setColour(panel);g.fillRoundedRectangle(r.toFloat(),10.f);
    g.setColour(border);g.drawRoundedRectangle(r.toFloat(),10.f,1.f);
    g.setColour(accent);g.fillRoundedRectangle(float(r.getX()+18),float(r.getY()+18),3.f,20.f,1.5f);
}
}

FlysnapperLook::FlysnapperLook(){
    setColour(juce::Label::textColourId,text);
    setColour(juce::ComboBox::backgroundColourId,background);setColour(juce::ComboBox::textColourId,text);
    setColour(juce::ComboBox::outlineColourId,border);setColour(juce::ComboBox::arrowColourId,orange);
    setColour(juce::PopupMenu::backgroundColourId,panel);setColour(juce::PopupMenu::textColourId,text);
    setColour(juce::PopupMenu::highlightedBackgroundColourId,border);setColour(juce::PopupMenu::highlightedTextColourId,orange);
    setColour(juce::TextButton::buttonColourId,panel);setColour(juce::TextButton::textColourOffId,text);
    setColour(juce::TextButton::textColourOnId,text);setColour(juce::TextButton::buttonOnColourId,orange.withAlpha(.22f));
    setColour(juce::ToggleButton::textColourId,text);setColour(juce::ToggleButton::tickColourId,orange);
    setColour(juce::TooltipWindow::backgroundColourId,juce::Colour(0xff283644));
    setColour(juce::TooltipWindow::textColourId,text);setColour(juce::TooltipWindow::outlineColourId,border);
    setColour(juce::ScrollBar::thumbColourId,border.brighter(.3f));
}
void FlysnapperLook::drawToggleButton(juce::Graphics& g,juce::ToggleButton& button,bool over,bool down){
    const float y=(button.getHeight()-18.f)*.5f;
    drawTickBox(g,button,1.f,y,18.f,18.f,button.getToggleState(),button.isEnabled(),over,down);
    g.setColour(text.withMultipliedAlpha(button.isEnabled()?1.f:.5f));
    g.setFont(juce::Font(juce::FontOptions(14.f)));
    g.drawText(button.getButtonText(),26,0,button.getWidth()-26,button.getHeight(),juce::Justification::centredLeft);
}
juce::Font FlysnapperLook::getComboBoxFont(juce::ComboBox& box){
    return box.getProperties().getWithDefault("compactScaleMenu",false)
        ?juce::Font(juce::FontOptions(13.f)):juce::LookAndFeel_V4::getComboBoxFont(box);
}

FlysnapperScaleAttachment::FlysnapperScaleAttachment(juce::RangedAudioParameter& parameter,juce::ComboBox& control,std::function<void()> onChange)
    :box(control),changed(std::move(onChange)),attachment(parameter,[this](float value){
        box.setSelectedId(std::clamp(juce::roundToInt(value),0,flysnapper::scaleCount-1)+1,juce::dontSendNotification);
        if(changed)changed();
    }){
    box.addListener(this);attachment.sendInitialUpdate();
}
FlysnapperScaleAttachment::~FlysnapperScaleAttachment(){box.removeListener(this);}
void FlysnapperScaleAttachment::comboBoxChanged(juce::ComboBox*){
    const int index=box.getSelectedId()-1;
    if(index>=0&&index<flysnapper::scaleCount)attachment.setValueAsCompleteGesture(float(index));
}

int FlysnapperMappingTable::typeAt(int column,int row) noexcept {
    if(column<0||column>=columnCount||row<0||row>=columnRows[size_t(column)])return -1;
    const auto id=std::string_view(mappingOrder[column][row]);
    const auto& types=flysnapper::chordTypes();
    for(size_t i=0;i<types.size();++i)if(id==types[i].id)return int(i);
    return -1;
}
int FlysnapperMappingTable::columnForType(int type) noexcept {
    if(type<0||type>=flysnapper::chordTypeCount)return -1;
    for(int column=0;column<columnCount;++column)
        for(int row=0;row<columnRows[size_t(column)];++row)if(typeAt(column,row)==type)return column;
    return -1;
}
int FlysnapperMappingTable::rowForType(int type) noexcept {
    if(type<0||type>=flysnapper::chordTypeCount)return -1;
    for(int column=0;column<columnCount;++column)
        for(int row=0;row<columnRows[size_t(column)];++row)if(typeAt(column,row)==type)return row;
    return -1;
}
juce::Rectangle<int> FlysnapperMappingTable::columnBounds(int column) const noexcept {
    if(column<0||column>=columnCount)return {};
    constexpr int outside=8,gap=12;
    const int width=std::max(1,(getWidth()-2*outside-(columnCount-1)*gap)/columnCount);
    const int x=outside+column*(width+gap);
    return {x,0,column==columnCount-1?std::max(1,getWidth()-outside-x):width,getHeight()};
}
FlysnapperMappingTable::FlysnapperMappingTable(FlysnapperProcessor& processor){
    for(int column=0;column<columnCount;++column){
        label(columnHeaders[size_t(column)],mappingHeadings[column],13.f,orange,true);
        columnHeaders[size_t(column)].setComponentID("mappingColumn_"+juce::String(column));
        addAndMakeVisible(columnHeaders[size_t(column)]);
    }
    const auto& types=flysnapper::chordTypes();
    for(size_t i=0;i<types.size();++i){
        const auto& type=types[i];const auto id=juce::String(type.id);
        label(names[i],juce::String::fromUTF8(flysnapper::chordTypeDisplayNameInC(int(i)).c_str()),15.f,text,true);names[i].setComponentID("chordName_"+id);
        label(chordTones[i],"Chord tones: "+namesFor(flysnapper::chordToneMask(int(i))),11.f,muted);
        chordTones[i].setComponentID("chordTones_"+id);chordTones[i].setJustificationType(juce::Justification::topLeft);
        label(scaleTones[i],{},11.5f,green);scaleTones[i].setComponentID("scaleTones_"+id);scaleTones[i].setJustificationType(juce::Justification::topLeft);
        label(defaults[i],"Factory: "+juce::String::fromUTF8(flysnapper::scaleDefinitions()[size_t(type.defaultScale)].name),10.5f,muted);defaults[i].setJustificationType(juce::Justification::topLeft);
        defaults[i].setComponentID("factory_"+id);choices[i].setComponentID("mapping_"+id);
        populateScales(choices[i],flysnapper::chordToneMask(int(i)));
        choices[i].getProperties().set("compactScaleMenu",true);
        addAndMakeVisible(names[i]);addAndMakeVisible(chordTones[i]);addAndMakeVisible(choices[i]);
        addAndMakeVisible(scaleTones[i]);addAndMakeVisible(defaults[i]);
        if(auto* parameter=processor.parameters.getParameter(FlysnapperProcessor::mappingParameterId(int(i))))
            attachments[i]=std::make_unique<FlysnapperScaleAttachment>(*parameter,choices[i],[this,i]{updateRow(i);});
        updateRow(i);
    }
    setSize(1000,contentHeight);
}
void FlysnapperMappingTable::updateRow(size_t row){
    const int selected=choices[row].getSelectedId()-1;
    if(selected<0||selected>=flysnapper::scaleCount)return;
    const auto chordMask=flysnapper::chordToneMask(int(row));
    const auto& selectedScale=flysnapper::scaleDefinitions()[size_t(selected)];
    const auto missing=uint16_t(chordMask&~selectedScale.mask);
    juce::String description="Scale tones: "+namesFor(selectedScale.mask);
    if(missing)description+="    Outside scale: "+namesFor(missing);
    scaleTones[row].setText(description,juce::dontSendNotification);
    scaleTones[row].setColour(juce::Label::textColourId,missing?orange:green);
    juce::String tip="This scale type applies in the actual chord's root and is saved with this instance.\n";
    tip+="Selected scale: "+juce::String::fromUTF8(selectedScale.name)+"\nChord tones in C: "+namesFor(chordMask)+"\n"+description;
    tip+=missing?"\n! This scale omits chord tones. The choice remains available.":"\nThis scale contains all nominal chord tones.";
    choices[row].setTooltip(helpEnabled?tip:juce::String{});
    chordTones[row].setTooltip(helpEnabled?"Nominal chord-type formula in C. Recognition can allow some tones to be omitted; the formula itself is not editable.":juce::String{});
    scaleTones[row].setTooltip(helpEnabled?description:juce::String{});
    defaults[row].setTooltip(helpEnabled?defaults[row].getText()+"\nReset all 52 restores these factory assignments in this instance only.":juce::String{});
}
void FlysnapperMappingTable::setHelp(bool enabled){helpEnabled=enabled;for(size_t i=0;i<choices.size();++i)updateRow(i);}
void FlysnapperMappingTable::resized(){
    for(int column=0;column<columnCount;++column){
        const auto bounds=columnBounds(column);
        const int x=bounds.getX()+8,width=std::max(1,bounds.getWidth()-16);
        columnHeaders[size_t(column)].setBounds(x,4,width,22);
        for(int row=0;row<columnRows[size_t(column)];++row){
            const int type=typeAt(column,row);if(type<0)continue;const auto i=size_t(type);
            const int y=headerHeight+row*rowHeight;
            names[i].setBounds(x,y+3,width,19);
            chordTones[i].setBounds(x,y+24,width,14);
            choices[i].setBounds(x,y+41,width,24);
            scaleTones[i].setBounds(x,y+69,width,27);
            defaults[i].setBounds(x,y+99,width,22);
        }
    }
}
void FlysnapperMappingTable::paint(juce::Graphics& g){
    g.fillAll(panel);
    for(int column=0;column<columnCount;++column){
        const auto bounds=columnBounds(column);
        for(int row=0;row<columnRows[size_t(column)];++row){
            const int y=headerHeight+row*rowHeight;
            if(row%2==0){g.setColour(background.withAlpha(.35f));g.fillRect(bounds.getX(),y,bounds.getWidth(),rowHeight);}
            g.setColour(border.withAlpha(.5f));g.drawHorizontalLine(y+rowHeight-1,float(bounds.getX()+4),float(bounds.getRight()-4));
        }
    }
}

FlysnapperEditor::FlysnapperEditor(FlysnapperProcessor& p):AudioProcessorEditor(p),processor(p),mappingTable(p){
    setLookAndFeel(&look);setOpaque(true);setResizable(true,true);setResizeLimits(1040,760,1600,1300);
    label(title,"FLYSNAPPER",31.f,text,true);label(byline,juce::String::fromUTF8("by Olav L\xc3\xa6greid"),13.f,muted);
#ifdef JucePlugin_VersionString
    label(version,JucePlugin_VersionString,12.f,muted);
#else
    label(version,"0.4.4",12.f,muted);
#endif
    label(chord,"No chord input",42.f,text,true);chord.setComponentID("chordDisplay");chord.setMinimumHorizontalScale(.75f);
    label(activeScale,"Chromatic",18.f,green);activeScale.setComponentID("activeScale");
    label(chordTones,"Chord tones: none",14.f,muted);chordTones.setComponentID("receivedChordTones");
    label(chordStatus,"Chord control: channel 16",13.f,muted);chordStatus.setComponentID("chordStatus");label(allowedTitle,"ALLOWED NOTES",12.f,muted,true);
    label(midiTitle,"MIDI TO MIDI",16.f,orange,true);label(modeTitle,"MODE",12.f,muted,true);
    label(rootTitle,"FIXED ROOT",12.f,muted,true);label(scaleTitle,"FIXED SCALE",12.f,muted,true);
    label(fixedScaleTones,{},14.f,green);fixedScaleTones.setComponentID("fixedScaleTones");
    label(midiRouting,"Playing MIDI: channel 1    /    Chord control: channel 16",14.f,muted);
    label(activity,"MIDI output: idle",13.f,muted);label(eventStatus,{},12.f,muted);
    label(warning,"Note Correction off keeps chord analysis active.",12.f,muted);
    label(footer,"AGPL-3.0-or-later  /  See LICENSE.txt",11.f,muted);
    label(backTitle,"CHORD / SCALE SETUP",23.f,text,true);
    label(backDescription,"52 chord types, here assigned to root C. Your chosen scale type applies in the actual chord's root and is auto-saved with this instance.",14.f,text,true);
    // Use the typographic apostrophe required by the supplied UI wording.
    backDescription.setText(juce::String::fromUTF8("52 chord types, here assigned to root C. Your chosen scale type applies in the actual chord\xe2\x80\x99s root and is auto-saved with this instance."),juce::dontSendNotification);
    backDescription.setComponentID("backDescription");backDescription.setJustificationType(juce::Justification::topLeft);
    label(backTip,assignmentTip,13.f,muted);backTip.setComponentID("assignmentTip");backTip.setJustificationType(juce::Justification::topLeft);
    label(guideTitle,"FLYSNAPPER GUIDE",23.f,text,true);
    mode.addItem("Chord Tones Only",1);mode.addItem("Chord-Scale Assignment",2);mode.addItem("Fixed Scale",3);
    for(int n=0;n<12;++n)root.addItem(noteNames[n],n+1);populateScales(scale,0);
    mode.setComponentID("correctionMode");root.setComponentID("fixedRoot");scale.setComponentID("fixedScale");
    correction.setComponentID("correctionEnabled");chordThru.setComponentID("chordThru");help.setComponentID("help");
    flip.setComponentID("flip");panic.setComponentID("panic");routingHelp.setComponentID("routingHelp");
    viewport.setComponentID("mappingViewport");restore.setComponentID("resetMappings");
    guide.setComponentID("guide");guideClose.setComponentID("guideClose");guidePanel.setComponentID("guidePanel");guideText.setComponentID("guideText");
    addAndMakeVisible(front);
    for(auto* c:std::initializer_list<juce::Component*>{&chord,&activeScale,&chordTones,&chordStatus,&allowedTitle,&midiTitle,&modeTitle,&rootTitle,&scaleTitle,&fixedScaleTones,&midiRouting,&activity,&eventStatus,&mode,&root,&scale,&correction,&chordThru})front.addAndMakeVisible(c);
    for(int n=0;n<12;++n){label(notes[size_t(n)],noteNames[n],13.f,muted,true);notes[size_t(n)].setComponentID("allowedNote_"+juce::String(n));notes[size_t(n)].setJustificationType(juce::Justification::centred);front.addAndMakeVisible(notes[size_t(n)]);}
    viewport.setViewedComponent(&mappingTable,false);viewport.setScrollBarsShown(true,false);addChildComponent(viewport);addChildComponent(backTitle);addChildComponent(backDescription);addChildComponent(backTip);addChildComponent(restore);
    addChildComponent(guidePanel);guidePanel.addAndMakeVisible(guideTitle);guidePanel.addAndMakeVisible(guideClose);guidePanel.addAndMakeVisible(guideText);
    guideText.setMultiLine(true);guideText.setReadOnly(true);guideText.setScrollbarsShown(true);guideText.setCaretVisible(false);guideText.setPopupMenuEnabled(false);
    guideText.setColour(juce::TextEditor::backgroundColourId,panel);guideText.setColour(juce::TextEditor::textColourId,text);guideText.setColour(juce::TextEditor::outlineColourId,border);
    guideText.setFont(juce::Font(juce::FontOptions(15.f)));
    guideText.setText(R"GUIDE(VST3 INSTRUMENT AND MIDI ROUTING
Flysnapper loads as a VST3 instrument. It corrects MIDI and has a silent stereo audio output; it does not make sound. Its track therefore has an audio output in Live. Use the plugin's MIDI output to play an instrument on a receiving MIDI track.

On the receiving track, set the upper MIDI From selector to Flysnapper's track. In the lower selector, choose the plugin-specific Flysnapper entry. Put the destination instrument on that receiving track and set Monitor to In, or arm the track with Monitor set to Auto.

Playing notes arrive at Flysnapper on channel 1. Route the chord track to Flysnapper on channel 16. Other channels pass without note correction. Chord MIDI Through forwards channel-16 chord control to the plugin's MIDI output when enabled. Leave it off when the output feeds a sounding instrument, so chord-control notes do not also play that instrument.

NOTE CORRECTION AND DEVICE ACTIVATION
Automating Note Correction on/off preserves this instance's chord analysis. With correction off, playing pitches pass unchanged while chord-control messages are still followed. Already-held playing notes keep the output binding with which they began, so later Note Offs release the correct notes.

Leave the Flysnapper device enabled in Live while automating Note Correction. Live's Device Activator may stop the plugin's processing entirely. A disabled device cannot be assumed to follow chord changes or produce corrected MIDI, and a direct route to it is not automatically redirected to another instance.

CORRECTION MODES
Chord Tones Only corrects to the received chord's held pitch classes. Chord-Scale Assignment uses the scale assigned to the recognised chord type on the back. Fixed Scale uses the selected root and scale independently of chord input.

The nearest allowed MIDI note is selected without waiting for future notes. For equally close choices, direction comes from the two preceding raw input notes in the same source/channel stream, excluding the current note. Sequential legato overlap keeps this history. Multiple Note Ons at the same sample position in one stream use upward fallback, as does unavailable direction. No lookahead is added.

A new playing Note On rearticulates an already active output pitch with Note Off then Note On at the same sample position, using the new velocity. Held bindings, final-release counts and sustain handling are preserved. Chord changes affect new notes; held bindings remain stable. Empty or unrecognised chord input uses Chromatic passthrough in both chord-dependent modes. When the host explicitly reports stopped transport, all three modes use Chromatic passthrough. The saved mode, root and scale settings stay unchanged.

CHOOSING SCALES
All 38 scales remain selectable. Each chord-type menu first lists Scales with all chord tones, then Chord tones outside scale. Within each section the requested parent-family and mode order is retained. Harmonic Major modes follow Harmonic Minor modes and precede Diminished. An exclamation mark identifies a scale that omits nominal chord tones; the row names the missing tones. The choice is allowed and no hidden chord/scale union is added.

The playing view lists recognised chord tones in root position: root, third (or suspension), fifth, sixth where applicable, seventh, ninth, eleventh and thirteenth. Inversions do not put the bass first. Only received tones are listed; omitted tones are not added. With alternative chord names, the order follows the first recognised interpretation. Unrecognised note sets keep their pitch-class listing.

The back groups all 52 chord types into Major, Dominant 1, Dominant 2 and Minor columns. Scroll vertically to see the remaining rows. Each scale menu spans its column; the popup and tooltip show full scale names. Chord-type and mapping scale tones are displayed relative to C. The selected scale type transposes to the actual incoming chord root. Melodic Minor uses its ascending form in both directions. Pitch-class names may have enharmonic equivalents.

PRESETS AND INSTANCES
Every instance saves its own 52 assignments, fixed scale and controls. Copying a device copies its saved settings; subsequent edits remain independent. Reset all 52 restores this instance's factory assignments. It does not reset another instance.

HELP, PANIC AND TIMING
Help enables contextual tooltips. Guide and front/back changes do not alter MIDI. Panic releases tracked playing notes and clears chord analysis. The MIDI routing test sends a brief C note; it is a routing check, not a played performance.

Flysnapper adds no intentional note-analysis delay. Host buffers, routing and the receiving instrument can still contribute to audible latency. The stereo audio output remains silent. Flysnapper has no audio input or pitch detector.
)GUIDE",false);
    for(auto* c:std::initializer_list<juce::Component*>{&title,&byline,&version,&flip,&panic,&routingHelp,&help,&guide,&warning,&footer})addAndMakeVisible(c);
    using ButtonAttachment=juce::AudioProcessorValueTreeState::ButtonAttachment;
    using ComboAttachment=juce::AudioProcessorValueTreeState::ComboBoxAttachment;
    correctionAttachment=std::make_unique<ButtonAttachment>(processor.parameters,"correction",correction);
    chordThruAttachment=std::make_unique<ButtonAttachment>(processor.parameters,"chordThru",chordThru);
    helpAttachment=std::make_unique<ButtonAttachment>(processor.parameters,"help",help);
    modeAttachment=std::make_unique<ComboAttachment>(processor.parameters,"mode",mode);
    rootAttachment=std::make_unique<ComboAttachment>(processor.parameters,"root",root);
    if(auto* parameter=processor.parameters.getParameter("scale"))scaleAttachment=std::make_unique<FlysnapperScaleAttachment>(*parameter,scale,[this]{timerCallback();});
    flip.onClick=[this]{setBackVisible(!backVisible);};panic.onClick=[this]{processor.requestPanic();};restore.onClick=[this]{resetMappings();};
    routingHelp.onClick=[this]{showRoutingHelp();};guide.onClick=[this]{setGuideVisible(!guideVisible);};guideClose.onClick=[this]{setGuideVisible(false);};help.onClick=[this]{setHelp(help.getToggleState());};
    addTip(mode,"Chord Tones Only uses held chord tones. Chord-Scale Assignment uses the mapping for the recognised chord type. Fixed Scale ignores chord input when choosing allowed notes. Chord-dependent modes use Chromatic passthrough with empty or unrecognised chord input. Explicitly stopped host transport uses Chromatic passthrough in all three modes.");
    addTip(root,"Root of Fixed Scale. Chord-dependent modes use the received chord's root.");
    addTip(scale,"All 38 fixed scales, ordered by parent family and mode. The selection is saved with this instance.");
    addTip(correction,"Automate this control to enable or disable note correction while continuing to receive chord changes. Existing held notes retain their original output binding.");
    addTip(chordTones,"Received chord tones in root position: root, third (or suspension), fifth, sixth, seventh, ninth, eleventh and thirteenth. Only sounding pitch classes are listed. The order follows the first recognised chord interpretation, regardless of inversion.");
    addTip(chordThru,"Forward channel-16 chord control unchanged to the plugin's MIDI output. Leave off when routing to a sounding instrument; enable only when a following MIDI processor needs the chord-control messages.");
    addTip(flip,"Flip to all 52 independent chord/scale assignments. Editing the view itself does not change MIDI.");
    addTip(panic,"Release tracked notes and pedals and clear the current chord. Use this if playback was interrupted.");
    addTip(restore,"Restore all 52 factory choices in this instance only.");
    addTip(routingHelp,"Read how to route this VST3 instrument's MIDI output to a receiving track using Live's plugin-specific MIDI From selector.");
    addTip(help,"Enable or disable contextual tooltips. The built-in guide remains available.");addTip(guide,"Open the built-in MIDI correction and routing guide.");addTip(guideClose,"Return to the previous controls.");
    for(auto& n:notes)addTip(n,"Allowed pitch classes for new corrected notes in the current mode.");
    setHelp(parameter("help")>=.5f);
    setSize(1040,760);timerCallback();startTimerHz(20);
}
FlysnapperEditor::~FlysnapperEditor(){stopTimer();viewport.setViewedComponent(nullptr,false);setLookAndFeel(nullptr);}
float FlysnapperEditor::parameter(const char* id)const{
    // A parameter attachment can run before APVTS updates its cached raw
    // value: parameter listeners are notified newest first. Read the actual
    // parameter for immediate, message-thread control previews.
    if(auto* p=processor.parameters.getParameter(id))return p->convertFrom0to1(p->getValue());
    return 0.f;
}
void FlysnapperEditor::addTip(juce::SettableTooltipClient& client,const juce::String& value){tips.emplace_back(&client,value);}
void FlysnapperEditor::setHelp(bool enabled){helpState=enabled;for(auto& tip:tips)tip.first->setTooltip(enabled?tip.second:juce::String{});mappingTable.setHelp(enabled);}
void FlysnapperEditor::setBackVisible(bool shown){
    backVisible=shown;guideVisible=false;guidePanel.setVisible(false);guide.setToggleState(false,juce::dontSendNotification);
    front.setVisible(!shown);viewport.setVisible(shown);backTitle.setVisible(shown);backDescription.setVisible(shown);backTip.setVisible(shown);restore.setVisible(shown);
    flip.setButtonText(shown?"Back to playing":"Chord / scale setup");resized();repaint();
}
void FlysnapperEditor::setGuideVisible(bool shown){
    guideVisible=shown;guidePanel.setVisible(shown);guide.setToggleState(shown,juce::dontSendNotification);
    front.setVisible(!shown&&!backVisible);viewport.setVisible(!shown&&backVisible);
    backTitle.setVisible(!shown&&backVisible);backDescription.setVisible(!shown&&backVisible);backTip.setVisible(!shown&&backVisible);restore.setVisible(!shown&&backVisible);repaint();
}
void FlysnapperEditor::showRoutingHelp(){setGuideVisible(true);guideText.moveCaretToTop(false);}
void FlysnapperEditor::resetMappings(){
    const auto defaults=flysnapper::factoryDefaults();
    for(int i=0;i<flysnapper::chordTypeCount;++i)if(auto* p=processor.parameters.getParameter(FlysnapperProcessor::mappingParameterId(i))){p->beginChangeGesture();p->setValueNotifyingHost(p->convertTo0to1(float(defaults[size_t(i)])));p->endChangeGesture();}
}
void FlysnapperEditor::timerCallback(){
    const bool currentHelp=parameter("help")>=.5f;if(currentHelp!=helpState)setHelp(currentHelp);
    const auto snapshot=processor.getSnapshot();
    const auto chordText=flysnapper::formatChord(snapshot);
    chord.setText(snapshot.chordMask==0?juce::String("No chord input"):chordText.empty()?juce::String("Unrecognised chord"):juce::String::fromUTF8(chordText.c_str()),juce::dontSendNotification);
    chordTones.setText("Chord tones: "+juce::String::fromUTF8(flysnapper::chordToneNamesInRootPosition(snapshot.chordMask,snapshot.root,snapshot.typeIndex).c_str()),juce::dontSendNotification);
    const int currentMode=std::clamp(juce::roundToInt(parameter("mode")),0,2);
    const int selected=std::clamp(juce::roundToInt(parameter("scale")),0,flysnapper::scaleCount-1);
    const int selectedRoot=std::clamp(juce::roundToInt(parameter("root")),0,11);
    const bool fixed=currentMode==2;root.setEnabled(fixed);scale.setEnabled(fixed);rootTitle.setEnabled(fixed);scaleTitle.setEnabled(fixed);
    const bool stopped=processor.transportStopped();
    const bool chromaticFallback=stopped||(!fixed&&snapshot.typeIndex<0);
    const bool singleNote=snapshot.chordMask!=0&&(snapshot.chordMask&(snapshot.chordMask-1))==0;
    // Preview the current controls even while the host is stopped and has not
    // processed a block. Recognition still comes from the last input snapshot.
    int effectiveScale=chromaticFallback?0:fixed?selected:-1;
    int effectiveRoot=chromaticFallback?0:fixed?selectedRoot:snapshot.root;
    if(!chromaticFallback&&currentMode==1&&snapshot.typeIndex>=0&&snapshot.typeIndex<flysnapper::chordTypeCount)
        if(auto* value=processor.parameters.getParameter(FlysnapperProcessor::mappingParameterId(snapshot.typeIndex)))
            effectiveScale=std::clamp(juce::roundToInt(value->convertFrom0to1(value->getValue())),0,flysnapper::scaleCount-1);
    const bool enabled=parameter("correction")>=.5f;
    juce::String scaleText;
    if(!enabled)scaleText="Note Correction off";
    else if(chromaticFallback)scaleText="Chromatic  /  "+juce::String(stopped?"Transport stopped":snapshot.chordMask==0?"No chord input":singleNote?"Single note":"Unrecognised chord");
    else if(currentMode==0)scaleText="Chord Tones Only";
    else if(effectiveScale>=0&&effectiveRoot>=0){
        scaleText=juce::String::fromUTF8(flysnapper::scaleDefinitions()[size_t(effectiveScale)].name);
        scaleText="Root "+juce::String(noteNames[effectiveRoot%12])+"  /  "+scaleText;
    }else scaleText="Chromatic";
    activeScale.setText(scaleText,juce::dontSendNotification);
    fixedScaleTones.setText("Fixed scale tones: "+namesFor(flysnapper::rotateMask(flysnapper::scaleDefinitions()[size_t(selected)].mask,selectedRoot)),juce::dontSendNotification);
    fixedScaleTones.setColour(juce::Label::textColourId,fixed&&!stopped?green:muted);
    const juce::String recognition=snapshot.typeIndex>=0?(snapshot.candidateCount>1?"recognition has alternatives":"recognised"):snapshot.chordMask==0?"no chord input":singleNote?"single note":"unrecognised chord";
    chordStatus.setText("Chord control: channel 16  /  "+recognition+(stopped?"  /  transport stopped":"")+(parameter("chordThru")>=.5f?"  /  forwarded":"  /  consumed here"),juce::dontSendNotification);
    uint16_t previewMask=!enabled||chromaticFallback?0xfff:currentMode==0?snapshot.chordMask:0;
    if(enabled&&effectiveScale>=0&&effectiveRoot>=0)
        previewMask=flysnapper::rotateMask(flysnapper::scaleDefinitions()[size_t(effectiveScale)].mask,effectiveRoot);
    for(int n=0;n<12;++n){const bool allowed=(previewMask&(1u<<n))!=0;notes[size_t(n)].setColour(juce::Label::textColourId,allowed?background:muted);notes[size_t(n)].setColour(juce::Label::backgroundColourId,allowed?green:background);}
    const auto count=processor.outputNotes();if(count!=previousOutputCount){activityTicks=8;previousOutputCount=count;}else activityTicks=std::max(0,activityTicks-1);
    activity.setText(activityTicks>0?"MIDI output: active":"MIDI output: idle",juce::dontSendNotification);activity.setColour(juce::Label::textColourId,activityTicks>0?green:muted);
    eventStatus.setText("Output events: "+juce::String(processor.outputEvents())+"    Dropped input events: "+juce::String(processor.droppedEvents()),juce::dontSendNotification);
    warning.setText(processor.capacityFault()?"MIDI capacity reached: tracked notes were released. Reduce the incoming event density.":"Note Correction off keeps chord analysis active.",juce::dontSendNotification);
    warning.setColour(juce::Label::textColourId,processor.capacityFault()?orange:muted);
}
void FlysnapperEditor::paint(juce::Graphics& g){
    g.fillAll(background);g.setColour(border);g.drawHorizontalLine(87,24.f,float(getWidth()-24));
    if(!backVisible&&!guideVisible){drawPanel(g,chordPanel,green);drawPanel(g,midiPanel,orange);}
    if(backVisible&&!guideVisible){g.setColour(panel);g.fillRoundedRectangle(viewport.getBounds().toFloat(),10.f);}
    if(guideVisible){g.setColour(panel);g.fillRoundedRectangle(guidePanel.getBounds().toFloat(),10.f);}
}
void FlysnapperEditor::resized(){
    const int w=getWidth(),h=getHeight();
    title.setBounds(24,20,235,40);byline.setBounds(26,61,280,18);version.setBounds(257,34,65,20);
    flip.setBounds(w-224,27,200,32);guide.setBounds(w-310,27,76,32);help.setBounds(w-386,29,66,29);
    panic.setBounds(w-472,27,76,32);routingHelp.setBounds(w-598,27,116,32);
    warning.setBounds(24,h-53,w-48,20);footer.setBounds(24,h-28,w-48,17);
    front.setBounds(getLocalBounds());chordPanel={24,105,w-48,205};midiPanel={24,328,w-48,h-401};
    chord.setBounds(48,116,w-96,60);activeScale.setBounds(48,180,w-96,28);chordTones.setBounds(48,214,w-96,23);chordStatus.setBounds(48,243,w-96,20);
    allowedTitle.setBounds(48,279,110,18);
    const int chipsX=178,gap=6,chipWidth=(w-chipsX-50-11*gap)/12;
    for(int n=0;n<12;++n)notes[size_t(n)].setBounds(chipsX+n*(chipWidth+gap),273,chipWidth,29);
    midiTitle.setBounds(56,344,210,24);correction.setBounds(48,380,(w-96)/2,29);chordThru.setBounds(w/2+12,380,w/2-60,29);
    modeTitle.setBounds(48,429,70,20);mode.setBounds(128,423,w-176,32);
    rootTitle.setBounds(48,473,96,20);scaleTitle.setBounds(160,473,w-208,20);
    root.setBounds(48,500,96,32);scale.setBounds(160,500,w-208,32);
    fixedScaleTones.setBounds(48,545,w-96,23);midiRouting.setBounds(48,575,w-96,23);
    activity.setBounds(48,h-118,220,22);eventStatus.setBounds(294,h-118,w-342,22);
    backTitle.setBounds(24,109,w-290,33);restore.setBounds(w-254,110,230,31);
    backDescription.setBounds(24,150,w-48,34);backTip.setBounds(24,190,w-48,46);
    viewport.setBounds(24,246,w-48,h-316);mappingTable.setSize(viewport.getWidth()-viewport.getScrollBarThickness(),FlysnapperMappingTable::contentHeight);
    guidePanel.setBounds(24,105,w-48,h-175);guideTitle.setBounds(24,15,w-350,34);guideClose.setBounds(w-278,17,206,31);guideText.setBounds(24,66,w-96,h-266);
}
