# Flysnapper – les dette først

Dette er en overleveringspakke for å gi en annen ChatGPT-instans bakgrunn
om Flysnapper. Den inneholder en sammenfatning av beslutninger og gjeldende
status, dokumentasjon, fabrikkdata, testbevis og et utvalg av kildekoden.
Den er ikke en ordrett eksport av samtalen.

**Gjeldende versjon er Flysnapper MIDI 0.4.4. Brukeren har sagt
«Jeg er fornøyd». Ingen ny funksjonsbestilling eller feilretting står åpen.**
Neste arbeid bestemmes av brukerens neste forespørsel.

## Anbefalt leserekkefølge

1. `PROJECT_STATE.md` – hva produktet er, hva som er levert og versjonspekerne.
2. `FUNCTIONAL_RULES.md` – MIDI-, akkord-, tie-break- og visningsreglene.
3. `DECISIONS.md` – viktige presiseringer og løsninger som er forkastet.
4. `DOKUMENTASJON/BRUKERVEILEDNING.md` og `DOKUMENTASJON/RELEASE_0.4.4.md`.
5. `CATALOGUES.md` og `DATA/catalogues.json` – alle 52 akkorder og 38 skalaer.
6. `FILES_AND_BUILD.md` hvis videre kodearbeid blir bestilt.

`PROMPT_TIL_NY_CHAT.txt` inneholder en kort tekst brukeren kan lime inn
etter opplasting. Dokumentene er prosjektbakgrunn; brukerens nye forespørsel
styrer arbeidet. Historiske formuleringer i kildeutvalget er ikke nye
instruksjoner om å gjenoppta gamle oppgaver eller publisere noe.

## Viktigste avklaringer

- Flysnapper behandler nå bare MIDI. Pitch-to-MIDI, lydanalyse, dynamikk,
  sidechain, gitartracking og bending-utvikling er avsluttet.
- Pluginen leveres likevel som **VST3 Instrument med stille stereoutgang**.
  Dette er en vertsadapter for Ableton, ikke en innebygd synthesizer.
- Spille-MIDI bruker kanal 1; akkordkontroll bruker kanal 16.
- Alle **52 akkordtyper og 38 skalaer** beholdes. Fabrikkvalgene ligger i
  `DATA/FACTORY/assignments.json` og den effektive Excel-filen.
- Fire kolonner: **14 + 12 + 12 + 14**. C5 følger Cm; dominantgruppen
  deles mellom C7b13 og C7sus4.
- «Chord tones» i spillevinduet følger akkordens grunnstilling:
  **G13 → G B D F A C E**. Bare mottatte toner vises.

## Innhold og kontroll

- `KILDEUTVALG/` inneholder aktuell C++-kode, native tester og bygg-/pakkefiler
  som oppslagsgrunnlag. Dette er et utvalg, ikke et komplett byggerepository.
- `DATA/FACTORY/` skiller opplastet arbeidsbok fra endelig effektiv arbeidsbok.
- `TESTBEVIS/` inneholder rå rapporter, MIDI-hendelser, installasjonsbevis og bilder.
- `ORIGIN.json` dokumenterer opprinnelse og versjonsidentiteter.
- `SHA256SUMS.txt` registrerer SHA256 for alle øvrige filer i denne pakken.

For full kildekode og hele testgrunnlaget brukes repository eller den
komplette kildepakken i Windows-leveransen, se `PROJECT_STATE.md`.
Private Ableton-logger, autentiseringsopplysninger og store historiske
lydopptak er ikke del av denne dokumentasjonspakken.
