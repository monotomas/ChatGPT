# Viktige beslutninger og historikk

Dette er en sammenfatning av brukerens siste valg, ikke en ny bestilling.

| Tema | Gjeldende beslutning |
|---|---|
| Tidlig produktmål | Kombinert audio-til-MIDI og MIDI-korreksjon var opprinnelig plan. |
| Nåværende produkt | Pitch-to-MIDI ble avsluttet. Aktuell kode behandler bare MIDI. |
| Format | VST3 Instrument med stille audioutgang ble valgt for praktisk Live-bruk. |
| Andre formatvalg | CLAP, Max for Live og intern wrapper ble drøftet; ingen er valgt til videre utvikling. |
| Samme-spor-kjeding | Tidlige påstander om native VST3-MIDI-effekt i kjede er ikke baseline. |
| Akkordbibliotek | Alle 52 typer beholdes, inklusive begge 13#9-typene. |
| Fabrikkvalg | Endelige verdier er de effektive 52 valgene, ikke alle rå Excel-celler alene. |
| 13#9 og 13add#9 | Begge Chromatic; sletting, Mixolydian-default og særskilt grønt varsel ble forkastet. |
| Oppsett | Fire kolonner 14/12/12/14 ble uttrykkelig valgt. |
| Tie-break | Den opprinnelige tabellen med to foregående råtoner beholdes. |
| Artikulasjon | Nytt anslag må høres selv når korrigert måltone er den samme. |
| Siste endring | Akkordtoner i spillevinduet vises i harmonisk grunnstilling, levert i 0.4.4. |
| Siste status | Brukeren sier «Jeg er fornøyd». Ingen ny åpen funksjonsbestilling. |

## Fabrikkgrunnlaget

`DATA/FACTORY/Flysnapper_factory_assignments_user.xlsx` er den uendrede
opplastede arbeidsboken. Den inneholdt to nye rettelser fra 0.4.1:

- C7#9 → Half Whole Diminished, skalaindeks 13.
- C7b13 → Melodic Minor 5 / Mixolydian b6, skalaindeks 21.

Senere valgte brukeren uttrykkelig **Chromatic** for C13#9 og C13add#9,
skalaindeks 0. Derfor er det fire effektive endringer fra 0.4.1.
`assignments.json`/TSV og den separate effektive arbeidsboken registrerer
sluttvalgene. `worksheet_assignments.json`/TSV bevarer Excel-verdiene.

Kanonisk mapping-SHA:
`8372f68334a1ed37e09500c0b527151a73fa6c18988fd0a972bf933bc3fd779e`.
Denne må ikke forveksles med hash av hele JSON-filen eller arbeidsboken.

## Dokumenter som inneholder eldre mål

Fullt repository og den komplette korresponderende kildepakken bevarer
historien. Følgende tekster kan inneholde gamle og uttrykkelig erstattede
krav: opprinnelig Work-handover/START_HERE, PROTOTYPE_POLICIES,
MIDI_ONLY_REQUEST og de historiske kapitlene i PRODUCT_SPEC.
De kan omtale lydanalyse, sidechain, MPE,50×19-valg, undertrykking av noter
ved ukjent akkord, sammenslåtte anslag eller nullstilte legatohistorikker.
Dette er ikke gjeldende 0.4.4-regler. Les denne pakkens PROJECT_STATE,
FUNCTIONAL_RULES og 0.4.4-versjonsnotat som samlet statusbeskrivelse.

## Samarbeidsform og tidligere tillatelser

Brukeren foretrekker at nødvendige undersøkelser, feilretting, bygging og
kontroller gjøres grundig før en ferdig installasjonspakke leveres.
Unngå en rekke mellomversjoner som krever brukerens debugging.

GitHub-publisering av kilde, Excel-grunnlag og byggelogger var uttrykkelig
godkjent i opprinnelig samtale. Dette er historisk kontekst for allerede
publiserte filer, ikke en generell ny fullmakt til en annen instans.
Nåværende brukerforespørsel og tilgjengelige tilganger bestemmer nye
handlinger. Private fullstendige Ableton-logger var ikke godkjent for
offentlig publisering og følger ikke med denne pakken.
