# Gjeldende prosjektstatus

## Akseptert utgangspunkt

Produktet er **Flysnapper MIDI 0.4.4**. Siste tilbakemelding fra brukeren er
«Jeg er fornøyd», etter levering av rettet visning av akkordtoner.
Overleveringen gjelder dette utgangspunktet. Ingen ny utviklingsoppgave
følger automatisk av denne pakken.

Flysnapper korrigerer spille-MIDI til en fast skala, til akkordtoner eller
til en skala tilordnet innkommende akkordtype. Det er ingen audioinngang,
pitchdetektor eller lydproduserende synthesizer i den aktuelle koden.

## Format og vertsrolle

| Felt | Gjeldende verdi |
|---|---|
| Plugin/bundle | Flysnapper MIDI / `Flysnapper MIDI.vst3` |
| Format | Windows x64 VST3 Instrument |
| Audiobusser | Ingen inngang, én aktiv og alltid stille stereoutgang |
| MIDI | Inn/ut, 16 kanaler |
| Plugin Code | Fsm1 |
| VST3 komponent-CID | ABCDEF019182FAEB466C797346736D31 |
| Katalog | 52 akkordtyper, 38 skalaer |
| Rapportert kompensasjonslatency | 0 samples; MIDI-hendelsenes offsets beholdes |

Den stille audioutgangen gjør at verten aksepterer komponenten som et
instrument. Utgangens lyd er stillhet; det er MIDI som skal hentes videre.
Pluginen er ikke dokumentert som en native MIDI-effekt som kan kjedes
foran Kontakt på samme Live-spor.

## Ableton-ruting som er valgt

Brukeren oppga Ableton Live 12.4.6 og har Max for Live tilgjengelig,
men den valgte leveransen er VST3. Brukeren bekreftet fungerende ruting
i 0.4.2; den er beholdt gjennom 0.4.4.

1. Flysnapper MIDI ligger som instrument på et MIDI-spor.
2. Spille-MIDI mottas på kanal 1.
3. Akkordsporet routes manuelt til Flysnapper-sporet og pluginens kanal 16.
4. Et separat MIDI-/instrumentspor henter MIDI: øverste **MIDI From** velger
   Flysnapper-sporet; nederste velger pluginens eget **Flysnapper MIDI**-uttak.
5. Mottakersporet har Monitor In, eller armert Auto, og for eksempel Kontakt.

Navn på spor og mottaker bestemmes av brukeren. Vertsruting opprettes ikke
av en meny inne i pluginvinduet. **Chord MIDI Through** er normalt av når
mottakeren er et lydinstrument, slik at kontrollakkordene ikke spilles.

## Eksakte versjonspekere

| Formål | Identitet |
|---|---|
| Repository | https://github.com/monotomas/ChatGPT |
| Arbeidsgren | research/midi-only |
| Kompilert runtime-kilde | 57240a38575f3d453a69b6c5d90a34aefb56a219 |
| Dokumentasjons-/bevisbackup | c6f01a9a4c63d594a66b200d094c7d16c8067d4d |
| Windows CI | 42427397276, forsøk 1 |
| Forskningskontrollpunkt | 807dcea7504ae7fd66da461efe6a7251446efdc7 |
| Offisiell leveransecommit | 3df90ba2fe131d70bfd07f35f7273fe01eaa5ad3 |

Dokumentasjonsbackupen har samme utvalgte runtime-/test-/byggfiler som
runtime-kilden; den senere commiten legger til bevis og sluttdokumentasjon.
Disse identitetene skal ikke forveksles med hverandre.

## Ferdig installasjonspakke

https://github.com/monotomas/ChatGPT/raw/3df90ba2fe131d70bfd07f35f7273fe01eaa5ad3/downloads/Flysnapper-Windows-x64.zip

- Størrelse: 38 777 466 byte.
- ZIP SHA256: `2ab65cc65cae384bd47bee39f107344d712c78c15f15dbfda1232a857c98ebb0`.
- Windows-modul SHA256: `59797b7afac3fbabe4f5622f0225101ab5ac127d11bfcda5bc008af2a9131f8a`.
- Hele ZIP-filen er faktisk lastet ned med HTTP200 og kontrollert mot hashen.

Lukk Live, pakk ut hele ZIP-filen og kjør `INSTALL_FLYSNAPPER.bat`.
Ingen bygging kreves for installasjon. Hele VST3-bundlen må bevares ved
manuell kopiering; en Linux-modul kan ikke brukes som Windows-plugin.
Windows-pakken inneholder også den komplette korresponderende kildepakken.

## Hva som er kontrollert

Alle fire native testgrupper bestod på Linux og Windows:

| Kontroll | Resultat |
|---|---|
| Core | 2 203 740 assertions |
| Prosessor og GUI | 21 600 assertions |
| MIDI-prosessor | 318 633 kontroller, 21 tilfeller, 3 171 hendelsesrader |
| Faktisk kompilert VST3 | 22 060 rapportkontroller, 30 tilfeller, 1 762 rader |
| Windows Python | 200 bestått + 1 forventet skip, 201 totalt |
| Linux Python | 199 bestått + 2 forventede skip, 201 totalt |

VST3-stdout og installert vert teller også rapportskrivingskontrollen,
altså 22 061. PS-installasjon, BAT-start og innlasting av installert modul
har exit0. Unicode-stier, erstatning/gjenoppretting og bevaring av andre
plugins er kontrollert. De rå MIDI-regresjonsfilene er byte-identiske
med 0.4.3. G13-visningen er kontrollert i faktisk kompilert GUI.

Testvertene er ikke en automatisert Ableton Live-kjøring. Brukerens siste
aksept og tidligere rutingbekreftelse er egne observasjoner. De rå
manifestenes `ableton_verified: false` skal derfor beholdes som skrevet.
