# Katalog: 52 akkordtyper og 38 skalaer

Eksportert fra den utgitte kildekoden og kontrollert mot alle endelige fabrikkvalg.

Indekser er stabile og 0-baserte; kolonne/rad i visningen er 1-basert.
Halvtoner angir numerisk sortert toneklasseinnhold relativt til grunntonen,
ikke spillevinduets harmoniske rekkefølge. Fortegn kan ha enharmoniske navn.

## Alle 38 skalaer

| Indeks | Skala | ID | Halvtoner fra roten |
|---:|---|---|---|
| 0 | Chromatic | `chromatic` | 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11 |
| 1 | Ionian (Major) | `ionian` | 0, 2, 4, 5, 7, 9, 11 |
| 5 | Dorian | `dorian` | 0, 2, 3, 5, 7, 9, 10 |
| 6 | Phrygian | `phrygian` | 0, 1, 3, 5, 7, 8, 10 |
| 7 | Lydian | `lydian` | 0, 2, 4, 6, 7, 9, 11 |
| 8 | Mixolydian | `mixolydian` | 0, 2, 4, 5, 7, 9, 10 |
| 2 | Aeolian (Minor) | `aeolian` | 0, 2, 3, 5, 7, 8, 10 |
| 9 | Locrian | `locrian` | 0, 1, 3, 5, 6, 8, 10 |
| 4 | Melodic Minor 1 | `melodic_minor` | 0, 2, 3, 5, 7, 9, 11 |
| 19 | Mel. Min. 2: Dorian ♭2 (Phrygian ♮6) | `melodic_minor_2` | 0, 1, 3, 5, 7, 9, 10 |
| 20 | Mel. Min. 3: Lydian Augmented (Lydian ♯5) | `melodic_minor_3` | 0, 2, 4, 6, 8, 9, 11 |
| 15 | Mel. Min. 4: Lydian Dominant | `lydian_dominant` | 0, 2, 4, 6, 7, 9, 10 |
| 21 | Mel. Min. 5: Mixolydian ♭6 (Hindu) | `melodic_minor_5` | 0, 2, 4, 5, 7, 8, 10 |
| 22 | Mel. Min. 6: Aeolian ♭5 (Locrian ♮2 / Half Dim.) | `melodic_minor_6` | 0, 2, 3, 5, 6, 8, 10 |
| 16 | Mel. Min. 7: Altered (Super Locrian) | `altered` | 0, 1, 3, 4, 6, 8, 10 |
| 28 | Dominant Bebop Scale | `bebop_dominant` | 0, 2, 4, 5, 7, 9, 10, 11 |
| 29 | Major Bebop Scale | `bebop_major` | 0, 2, 4, 5, 7, 8, 9, 11 |
| 30 | Minor / Dorian Bebop Scale | `bebop_dorian` | 0, 2, 3, 5, 7, 9, 10, 11 |
| 3 | Harm. Min. 1: Harmonic Minor | `harmonic_minor` | 0, 2, 3, 5, 7, 8, 11 |
| 23 | Harm. Min. 2: Locrian ♮6 | `harmonic_minor_2` | 0, 1, 3, 5, 6, 9, 10 |
| 24 | Harm. Min. 3: Ionian ♯5 | `harmonic_minor_3` | 0, 2, 4, 5, 8, 9, 11 |
| 25 | Harm. Min. 4: Dorian ♯4 | `harmonic_minor_4` | 0, 2, 3, 6, 7, 9, 10 |
| 17 | Harm. Min. 5: Phrygian Dominant | `phrygian_dominant` | 0, 1, 4, 5, 7, 8, 10 |
| 26 | Harm. Min. 6: Lydian ♯2 | `harmonic_minor_6` | 0, 3, 4, 6, 7, 9, 11 |
| 27 | Harm. Min. 7: Ultralocrian | `harmonic_minor_7` | 0, 1, 3, 4, 6, 8, 9 |
| 31 | Harmonic Major 1 | `harmonic_major` | 0, 2, 4, 5, 7, 8, 11 |
| 32 | Harmonic Major 2 (Dorian b5) | `harmonic_major_mode2` | 0, 2, 3, 5, 6, 9, 10 |
| 33 | Harmonic Major 3 (Phrygian b4) | `harmonic_major_mode3` | 0, 1, 3, 4, 7, 8, 10 |
| 34 | Harmonic Major 4 (Lydian b3) | `harmonic_major_mode4` | 0, 2, 3, 6, 7, 9, 11 |
| 35 | Harmonic Major 5 (Mixolydian b2) | `harmonic_major_mode5` | 0, 1, 4, 5, 7, 9, 10 |
| 36 | Harmonic Major 6 (Lydian Augmented #2) | `harmonic_major_mode6` | 0, 3, 4, 6, 8, 9, 11 |
| 37 | Harmonic Major 7 (Locrian bb7) | `harmonic_major_mode7` | 0, 1, 3, 5, 6, 8, 9 |
| 13 | Half Whole Diminished | `diminished_half_whole` | 0, 1, 3, 4, 6, 7, 9, 10 |
| 14 | Whole Half Diminished | `diminished_whole_half` | 0, 2, 3, 5, 6, 8, 9, 11 |
| 10 | Whole Tone | `whole_tone` | 0, 2, 4, 6, 8, 10 |
| 11 | Major Pentatonic | `major_pentatonic` | 0, 2, 4, 7, 9 |
| 12 | Minor Pentatonic | `minor_pentatonic` | 0, 3, 5, 7, 10 |
| 18 | Minor Blues | `minor_blues` | 0, 3, 5, 6, 7, 10 |

## De fire akkordkolonnene

| Kolonne | Antall | Første → siste |
|---:|---:|---|
| 1 | 14 | C Major → CMaj13#11 |
| 2 | 12 | C7 → C7b13 |
| 3 | 12 | C7sus4 → C13sus4b9 |
| 4 | 14 | Cm → Cdim7 |

C5 står rett etter Cm. ID-er og lagringsindekser er uavhengige av visningsrekkefølgen.

## Alle 52 akkordtyper med fabrikkvalg

| Indeks | Akkord i C | ID | Halvtoner fra roten | Fabrikkskala | Kol./rad |
|---:|---|---|---|---|---|
| 0 | C Major | `major` | 0, 4, 7 | Ionian (Major) | 1/1 |
| 2 | Csus2 | `sus2` | 0, 2, 7 | Mixolydian | 1/2 |
| 3 | Csus4 | `sus4` | 0, 5, 7 | Dorian | 1/3 |
| 6 | C6 | `major_sixth` | 0, 4, 7, 9 | Ionian (Major) | 1/4 |
| 8 | C6/9 | `six_nine` | 0, 2, 4, 7, 9 | Ionian (Major) | 1/5 |
| 10 | CMaj7 | `major_seventh` | 0, 4, 7, 11 | Lydian | 1/6 |
| 27 | CMaj7#5 | `major_seventh_sharp5` | 0, 4, 8, 11 | Mel. Min. 3: Lydian Augmented (Lydian ♯5) | 1/7 |
| 28 | CMaj7#9 | `major_seventh_sharp9` | 0, 3, 4, 7, 11 | Harm. Min. 6: Lydian ♯2 | 1/8 |
| 29 | CMaj7#11 | `major_seventh_sharp11` | 0, 4, 6, 7, 11 | Lydian | 1/9 |
| 31 | CMaj9 | `major_ninth` | 0, 2, 4, 7, 11 | Lydian | 1/10 |
| 51 | CMaj9#11 | `major_ninth_sharp11` | 0, 2, 4, 6, 7, 11 | Lydian | 1/11 |
| 37 | CMaj11 | `major_eleventh` | 0, 2, 4, 5, 7, 11 | Ionian (Major) | 1/12 |
| 41 | CMaj13 | `major_thirteenth` | 0, 2, 4, 5, 7, 9, 11 | Ionian (Major) | 1/13 |
| 50 | CMaj13#11 | `major_thirteenth_sharp11` | 0, 2, 4, 6, 7, 9, 11 | Lydian | 1/14 |
| 9 | C7 | `dominant_seventh` | 0, 4, 7, 10 | Mixolydian | 2/1 |
| 5 | C5/7 | `power_seventh` | 0, 7, 10 | Dorian | 2/2 |
| 18 | C7#5 | `dominant_sharp5` | 0, 4, 8, 10 | Mel. Min. 7: Altered (Super Locrian) | 2/3 |
| 26 | C7#5#9 | `dominant_sharp5_sharp9` | 0, 3, 4, 8, 10 | Mel. Min. 7: Altered (Super Locrian) | 2/4 |
| 25 | C7#5b9 | `dominant_sharp5_flat9` | 0, 1, 4, 8, 10 | Mel. Min. 7: Altered (Super Locrian) | 2/5 |
| 20 | C7#9 | `dominant_sharp9` | 0, 3, 4, 7, 10 | Half Whole Diminished | 2/6 |
| 21 | C7#11 | `dominant_sharp11` | 0, 4, 6, 7, 10 | Mel. Min. 4: Lydian Dominant | 2/7 |
| 17 | C7b5 | `dominant_flat5` | 0, 4, 6, 10 | Mel. Min. 4: Lydian Dominant | 2/8 |
| 24 | C7b5#9 | `dominant_flat5_sharp9` | 0, 3, 4, 6, 10 | Mel. Min. 7: Altered (Super Locrian) | 2/9 |
| 23 | C7b5b9 | `dominant_flat5_flat9` | 0, 1, 4, 6, 10 | Mel. Min. 7: Altered (Super Locrian) | 2/10 |
| 19 | C7b9 | `dominant_flat9` | 0, 1, 4, 7, 10 | Harm. Min. 5: Phrygian Dominant | 2/11 |
| 22 | C7b13 | `dominant_flat13` | 0, 4, 7, 8, 10 | Mel. Min. 5: Mixolydian ♭6 (Hindu) | 2/12 |
| 15 | C7sus4 | `dominant_sus4` | 0, 5, 7, 10 | Dorian | 3/1 |
| 16 | C7sus4b9 | `dominant_sus4_flat9` | 0, 1, 5, 7, 10 | Mel. Min. 2: Dorian ♭2 (Phrygian ♮6) | 3/2 |
| 30 | C9 | `dominant_ninth` | 0, 2, 4, 7, 10 | Mel. Min. 4: Lydian Dominant | 3/3 |
| 35 | C9#11 | `ninth_sharp11` | 0, 2, 4, 6, 7, 10 | Mel. Min. 4: Lydian Dominant | 3/4 |
| 34 | C9sus4 | `ninth_sus4` | 0, 2, 5, 7, 10 | Mixolydian | 3/5 |
| 36 | C11 | `dominant_eleventh` | 0, 2, 4, 5, 7, 10 | Mixolydian | 3/6 |
| 40 | C13 | `dominant_thirteenth` | 0, 2, 4, 5, 7, 9, 10 | Mixolydian | 3/7 |
| 44 | C13#9 | `thirteenth_sharp9` | 0, 3, 4, 5, 7, 9, 10 | Chromatic | 3/8 |
| 48 | C13add#9 | `thirteenth_add_sharp9` | 0, 2, 3, 4, 5, 7, 9, 10 | Chromatic | 3/9 |
| 43 | C13b9 | `thirteenth_flat9` | 0, 1, 4, 5, 7, 9, 10 | Harmonic Major 5 (Mixolydian b2) | 3/10 |
| 45 | C13sus4 | `thirteenth_sus4` | 0, 2, 5, 7, 9, 10 | Mixolydian | 3/11 |
| 46 | C13sus4b9 | `thirteenth_sus4_flat9` | 0, 1, 5, 7, 9, 10 | Harmonic Major 5 (Mixolydian b2) | 3/12 |
| 1 | Cm | `minor` | 0, 3, 7 | Aeolian (Minor) | 4/1 |
| 4 | C5 | `power` | 0, 7 | Minor Pentatonic | 4/2 |
| 7 | Cm6 | `minor_sixth` | 0, 3, 7, 9 | Melodic Minor 1 | 4/3 |
| 11 | Cm7 | `minor_seventh` | 0, 3, 7, 10 | Dorian | 4/4 |
| 13 | Cm7b5 | `half_diminished` | 0, 3, 6, 10 | Mel. Min. 6: Aeolian ♭5 (Locrian ♮2 / Half Dim.) | 4/5 |
| 32 | Cm9 | `minor_ninth` | 0, 2, 3, 7, 10 | Dorian | 4/6 |
| 38 | Cm11 | `minor_eleventh` | 0, 2, 3, 5, 7, 10 | Dorian | 4/7 |
| 39 | Cm11b5 | `minor_eleventh_flat5` | 0, 2, 3, 5, 6, 10 | Mel. Min. 6: Aeolian ♭5 (Locrian ♮2 / Half Dim.) | 4/8 |
| 47 | Cm13 | `minor_thirteenth` | 0, 2, 3, 5, 7, 9, 10 | Dorian | 4/9 |
| 49 | Cm13b5 | `minor_thirteenth_flat5` | 0, 2, 3, 5, 6, 9, 10 | Harmonic Major 2 (Dorian b5) | 4/10 |
| 12 | CmMaj7 | `minor_major_seventh` | 0, 3, 7, 11 | Melodic Minor 1 | 4/11 |
| 33 | CmMaj9 | `minor_major_ninth` | 0, 2, 3, 7, 11 | Harm. Min. 1: Harmonic Minor | 4/12 |
| 42 | CmMaj13 | `minor_major_thirteenth` | 0, 2, 3, 5, 7, 9, 11 | Melodic Minor 1 | 4/13 |
| 14 | Cdim7 | `diminished_seventh` | 0, 3, 6, 9 | Whole Half Diminished | 4/14 |
