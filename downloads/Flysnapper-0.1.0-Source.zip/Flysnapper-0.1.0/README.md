# Flysnapper 0.1.0

Første VST3-prototype for **ruting og MIDI-korreksjon**, laget fra handoverens spesifikasjon 2. Målplattformen er Windows 11 x64 og Ableton Live 12 Suite. Dette er en egen plugin; Buffkiller skal fortsatt brukes og installeres separat.

Prototypen kan korrigere keyboard-MIDI til akkordtoner, brukerens skala per akkordtype eller en fast skala. Den har stor akkordvisning, Allowed Notes og en bakside med 50 uavhengige skalavalg. Alle 19 skalaer finnes på hver rad. Oppsettet lagres per plugininstans.

**Audio blir ennå ikke gjort om til MIDI.** Verken monofon eller polyfon pitchdeteksjon er implementert. Handoveren krever at VST3-rutingen avklares først. Sidechain-bussen og en intern testnote er med for denne avgrensede prøven. Fullproduktet med live pitch-to-MIDI og brukerens latencykrav er derfor ikke ferdig.

## Pakken

- `Source/`: Flysnapper-kilde, korrigert akkordbibliotek og de to modulenes grensesnitt.
- `Tests/`: motor-, plugin-, faktisk VST3- og byggeskripttester.
- `build_plugin.py`, `BUILD_FLYSNAPPER.bat`: bygging, testing og valgfri Windows-installasjon.
- `dependencies.lock.json`: låst JUCE-kilde. Byggeren henter JUCE automatisk ved behov.
- `docs/PROTOTYPE_POLICIES.md`: foreløpige musikalske testregler og gjenværende valg.
- `docs/HOST_TEST_PLAN.md`: avgrenset prøve av den faktiske pluginen i Ableton.
- `docs/UI_SKETCH.svg`: illustrert forslag til GUI. Det er ikke et skjermbilde fra Ableton.
- `docs/screenshots/`: faktiske skjermbilder fra den kompilerte Linux-editoren.
- `docs/TEST_RESULTS.md`: utførte kontroller og gjenværende begrensninger.
- `.github/workflows/windows.yml`: manuell Windows-bygging i GitHub Actions, inkludert en sti med norske tegn. Denne arbeidsflyten er vedlagt, ikke kjørt i skymiljøet.
- `LICENSE.txt`, `THIRD_PARTY.md`: lisens og kildehenvisninger.

Faktisk utførte kontroller og deres grenser dokumenteres separat i leveransens testresultater. Et Linux-bygg eller en egen VST3-testvert er ikke en Windows-/MSVC- eller Ableton-test. Pakken inneholder ikke en ferdig Windows-binær med mindre dette er uttrykkelig angitt i testresultatene.

## Bygg og test på Windows

1. Pakk ut hele pakken til for eksempel `D:\Flysnapper`. Unngå å pakke den inn i Buffkiller-mappen. Stier med norske tegn støttes av byggerens Unicode-tilpasning.
2. Ha Python 3.10 eller nyere (3.12 anbefales), Git og Visual Studio 2022/nyere med C++-verktøy og Windows SDK tilgjengelig. Byggeren leter etter eksisterende verktøy og gir en konkret feilmelding om noe mangler. `--install-sdk` tillater uttrykkelig installasjon av manglende SDK; det er ikke standard.
3. Dobbeltklikk `BUILD_FLYSNAPPER.bat`, eller kjør følgende i pakkens mappe:

   ```bat
   py -3 build_plugin.py
   ```

Dette bygger Flysnapper, kjører de påkrevde testene og lager den testede pluginpakken under `dist`. **Standardkjøringen installerer ingenting.** JUCE låses til `8.0.16-security`, commit `ea77444750de45e036e0279bb0291144bf8e3688`; checksum-/TLS-kontroller skal ikke omgås. Førstegangskjøringen trenger tilgang til GitHub og eventuelle verktøykilder.

For bygging, testing og deretter installasjon:

```bat
py -3 build_plugin.py --install
```

Eller installer en allerede testet og hashkontrollert `dist`-pakke:

```bat
py -3 build_plugin.py --install-only
```

Legg til `--choose-install-dir` for å velge VST3-mappe, eller `--install-dir "D:\Mine VST3"` for en bestemt mappe. Standarddestinasjonen er Windows sin vanlige VST3-mappe. Lukk verten før installasjon. Installereren håndterer bare `Flysnapper.vst3` og beholder gjenopprettingsmulighet; den skal aldri erstatte `Buffkiller.vst3`. Testfeil skal løses før installasjon, ikke overstyres.

## Første avgrensede prøve i Live

Bruk **MPE deaktivert**. Kanal 16 er en foreløpig fast kanal for akkordkontroll, ikke keyboardets obligatoriske kanal.

1. Legg Flysnapper som instrument på et MIDI-spor. Vanlig keyboard-/track-MIDI går inn på dette sporet som normalt.
2. La akkordsporet sende direkte til Flysnapper-pluginen på mottakerkanal 16. Ikke filtrer Flysnapper-sporets vanlige inngang til bare kanal 16.
3. På et eget MIDI-spor med mottakerinstrument: velg Flysnapper-sporet som `MIDI From`, og velg **Flysnapper-pluginens MIDI-utgang** i den nedre velgeren. Bruk egnet monitorering.
4. Velg `Fixed Scale`, C og Major / Ionian for en første prøve uten akkordspor. G# (MIDI 68) uten retninghistorikk skal bli A (MIDI 69). `Send test note` sender internt generert MIDI 60 i 100 ms gjennom samme korreksjon.
5. Prøv `Chord Notes` med C–E–G på akkordsporet. Bare disse pitch classes skal være tillatt, i alle registre. Akkordkontrollens egne noter skal ikke sendes til mottakerinstrumentet.
6. Velg `Chord Scale`, åpne `Chord / scale setup` og endre en rad. For eksempel m7 → Dorian gjelder B Dorian over Bm7. Flip endrer bare visningen; noter skal fortsette.

Med korreksjon på og tomt akkordsett undertrykker denne prototypen nye noter i akkordmodus. Bruk `Fixed Scale`, spill en kontrollakkord eller slå av `Correction enabled` ved rutingtesten. `Panic` slipper Flysnapper-notene og tømmer akkord-/løpshistorikk.

Sidechain velges i vertens eget panel. UI viser om **bussen** er aktivert; dette beviser ikke at Live har valgt en audiokilde. Stillhet regnes ikke som frakobling. Ingen dry-audio sendes ut, og testnoten er ikke en pitchdetektor.

Følg deretter hele `docs/HOST_TEST_PLAN.md`. Lagre/gjenåpne, samtidige kilder, loop/seek, sidechain av/på og faktiske Live-kanaler må prøves i målverten før rutingen kan kalles verifisert der. En åpen port, en vellykket bygging eller pluginens rapporterte 0 samples beviser ikke live latency.

## Utvikling og lokale kontroller

Hver skyoppgave har sitt eget isolerte miljø. Bruk den eksisterende utsjekkingen; opprett ikke et ekstra Git-worktree som vanlig oppstartsarbeid.

Den avhengighetsfrie kjernen kan bygges og testes med CMake; bruk prosjektets `FLYSNAPPER_CORE_ONLY`-valg. For et fullstendig Linux-bygg brukes `python3 build_plugin.py --native` etter at JUCEs Linux-systemavhengigheter og en skjerm/virtuell skjerm er tilgjengelige. Det produserer en Linux-plugin og kan ikke erstatte Windows-binæren. `--jobs 2` begrenser parallell kompilering; bruk `--juce-dir` bare for en ren utsjekking av nøyaktig den låste JUCE-commiten.

Korreksjonen skal virke med GUI lukket. Akkordoppslag forberedes før sanntidsarbeidet; audiotråden bruker numeriske masker og avgrensede buffere. Fabrikkanbefalinger er redigerbare startverdier, ikke harmoniske begrensninger. Eksisterende Note On/Off-bindinger skal bestå ved endring av skala og ved flip.
