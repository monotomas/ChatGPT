// SPDX-License-Identifier: AGPL-3.0-or-later
#pragma once
#include <juce_audio_processors/juce_audio_processors.h>
#include "Core/MidiEngine.h"
#include <atomic>

class FlysnapperProcessor final : public juce::AudioProcessor, public juce::VST3ClientExtensions {
public:
    FlysnapperProcessor();
    const juce::String getName() const override { return "Flysnapper"; }
    void prepareToPlay(double,int) override;
    void releaseResources() override;
    bool isBusesLayoutSupported(const BusesLayout&) const override;
    void processBlock(juce::AudioBuffer<float>&,juce::MidiBuffer&) override;
    void processBlockBypassed(juce::AudioBuffer<float>&,juce::MidiBuffer&) override;
    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override {return true;}
    bool acceptsMidi() const override {return true;}
    bool producesMidi() const override {return true;}
    bool isMidiEffect() const override {return false;}
    bool supportsMPE() const override {return false;}
    bool getPluginHasMainInput() const override {return false;}
    double getTailLengthSeconds() const override {return 0;}
    int getNumPrograms() override {return 1;}
    int getCurrentProgram() override {return 0;}
    void setCurrentProgram(int) override {}
    const juce::String getProgramName(int) override {return "Default";}
    void changeProgramName(int,const juce::String&) override {}
    void getStateInformation(juce::MemoryBlock&) override;
    void setStateInformation(const void*,int) override;
    void reset() override { needsReset.store(true); }
    static juce::String mappingParameterId(int);
    flysnapper::Snapshot getSnapshot() const {return flysnapper::unpackSnapshot(display.load(std::memory_order_acquire));}
    bool sidechainActive() const {return sidechain.load(std::memory_order_relaxed);}
    unsigned outputNotes() const {return emitted.load(std::memory_order_relaxed);}
    bool capacityFault() const {return faulted.load(std::memory_order_relaxed);}
    unsigned droppedEvents() const {return dropped.load(std::memory_order_relaxed);}
    void requestTestNote() noexcept {testRequested.store(true);}
    void requestPanic() noexcept {needsReset.store(true);}
    juce::AudioProcessorValueTreeState parameters;
private:
    static juce::AudioProcessorValueTreeState::ParameterLayout parameterLayout();
    void process(juce::AudioBuffer<float>&,juce::MidiBuffer&,bool bypassed);
    static constexpr size_t inputCapacity=2048;
    struct Input {int offset=0; unsigned sequence=0; flysnapper::Source source=flysnapper::Source::External;
        std::array<juce::uint8,3> data{}; int length=0;};
    std::array<Input,inputCapacity> inputs{};
    flysnapper::Engine engine;
    flysnapper::Output output;
    juce::MidiBuffer result;
    std::array<std::atomic<float>*,50> mapValues{};
    std::atomic<float> *correction=nullptr,*mode=nullptr,*root=nullptr,*scale=nullptr,*routingTest=nullptr;
    std::atomic<uint64_t> display{0};
    std::atomic<bool> sidechain{false},needsReset{false},testRequested{false},faulted{false};
    std::atomic<unsigned> emitted{0},dropped{0};
    int64_t testRemaining=-1, expectedPosition=0;
    double sampleRate=48000;
    bool testWasHigh=false,wasPlaying=false,havePosition=false,wasSidechain=false;
    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(FlysnapperProcessor)
};
